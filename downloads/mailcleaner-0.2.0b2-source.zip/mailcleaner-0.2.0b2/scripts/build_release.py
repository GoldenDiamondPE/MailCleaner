"""Build only reviewed public files; never archive the working directory."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PUBLIC_FILES = (
    'bulk_runner.py', 'bulk_store.py', 'classifier.py', 'dashboard.py',
    'gmail_client.py', 'label_settings.py', 'local_backend.py', 'mail_actions.py',
    'mail_store.py', 'mailboxes.py', 'main.py', 'predictor.py', 'runtime_paths.py', 'update_check.py', 'backup_data.py',
    'pyproject.toml', 'requirements.txt', 'PUBLIC_README.md', 'README.md', '.gitignore',
    'Start MailCleaner.command', 'Install MailCleaner.command',
    'web/__init__.py', 'web/index.html', 'web/style.css', 'web/app.js', 'web/icon.svg',
    'docs/PRIVACY.md', 'docs/RELEASE.md', 'docs/ROADMAP.md',
    'scripts/build_release.py', 'site/index.html', 'site/style.css', 'site/icon.svg',
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def version():
    tree = ast.parse((ROOT / 'runtime_paths.py').read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VERSION' for t in node.targets):
            return ast.literal_eval(node.value)
    raise RuntimeError('Missing release version')


def archive(destination, files):
    # Stable ordering/timestamps, with no host usernames, absolute paths, or
    # extended attributes. Only the explicit paths supplied by the caller enter.
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as output:
        for name, path in sorted(files):
            if path.is_symlink():
                raise ValueError('Symlinks are not release inputs: ' + name)
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 17, 0, 0, 0))
            mode = 0o755 if name.endswith('.command') else 0o644
            info.external_attr = (0o100000 | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'dist')
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    # A version-specific directory avoids overwriting an earlier release.
    release_version = version()
    metadata = tomllib.loads((ROOT / 'pyproject.toml').read_text())
    if metadata['project']['version'] != release_version:
        parser.error('pyproject.toml and runtime_paths.py versions must match')
    site_html = (ROOT / 'site/index.html').read_text()
    expected_downloads = ('mailcleaner-' + release_version + '-source.zip',
                          'mailcleaner_local-' + release_version + '-py3-none-any.whl')
    if any(name not in site_html for name in expected_downloads):
        parser.error('Update the public page download links for this version')
    destination = output / release_version
    if destination.exists():
        parser.error('Release directory already exists; choose a clean --output directory')
    for name in PUBLIC_FILES:
        path = ROOT / name
        if not path.is_file() or path.is_symlink():
            parser.error('Missing or unsafe release input: ' + name)
    with tempfile.TemporaryDirectory(prefix='mailcleaner-public-build-') as temporary:
        temporary = Path(temporary)
        source = temporary / ('mailcleaner-' + release_version)
        source.mkdir()
        for name in PUBLIC_FILES:
            target = source / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
        wheel_output = temporary / 'wheel'
        environment = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1', 'SOURCE_DATE_EPOCH':'1794873600'}
        subprocess.run([sys.executable, '-m', 'build', '--no-isolation', '--wheel',
                        '--outdir', str(wheel_output), str(source)], env=environment, check=True)
        wheels = list(wheel_output.glob('*.whl'))
        if len(wheels) != 1:
            raise RuntimeError('Expected one wheel')
        source_zip = temporary / ('mailcleaner-' + release_version + '-source.zip')
        archive(source_zip, [(source.name + '/' + name, source / name) for name in PUBLIC_FILES])
        files = {name:digest(source / name) for name in PUBLIC_FILES}
        manifest = {'version':release_version, 'status':'beta candidate; release tests deferred',
                    'files':files, 'artifacts':{wheels[0].name:digest(wheels[0]), source_zip.name:digest(source_zip)}}
        manifest_path = temporary / 'release-manifest.json'
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
        public_site = temporary / 'public-site'
        public_site.mkdir()
        for name in ('index.html', 'style.css', 'icon.svg'):
            shutil.copyfile(source / 'site' / name, public_site / name)
        downloads = public_site / 'downloads'
        downloads.mkdir()
        for path in (wheels[0], source_zip, manifest_path):
            shutil.copyfile(path, downloads / path.name)
        (downloads / 'SHA256SUMS.txt').write_text(''.join(
            digest(path) + '  ' + path.name + '\n' for path in (wheels[0], source_zip, manifest_path)))
        site_zip = temporary / ('mailcleaner-' + release_version + '-public-site.zip')
        site_files = [(str(path.relative_to(public_site)), path) for path in public_site.rglob('*') if path.is_file()]
        archive(site_zip, site_files)
        # Build everything before creating a publishable output directory.
        destination.mkdir(parents=True)
        for path in (wheels[0], source_zip, site_zip, manifest_path):
            shutil.copyfile(path, destination / path.name)
        shutil.copytree(public_site, destination / 'public-site')
        (destination / 'SHA256SUMS.txt').write_text(''.join(
            digest(path) + '  ' + path.name + '\n' for path in (wheels[0], source_zip, site_zip, manifest_path)))
    print('Release candidate built: ' + str(destination))
    print('Private mailbox data excluded. Publishing and release tests remain separate steps.')


if __name__ == '__main__':
    main()
