"""Private backup snapshots and restore into a separate, empty data directory."""
import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from contextlib import closing
from pathlib import Path

from runtime_paths import DATA_DIR, VERSION

FILES = ('dashboard.sqlite3', 'mailcleaner.db', 'credentials.json', 'token.json', 'bridge-cert.pem')
DATABASES = {'dashboard.sqlite3', 'mailcleaner.db'}
MAX_FILE = 256 * 1024 * 1024
MAX_TOTAL = 512 * 1024 * 1024


def create_backup(destination):
    """Snapshot SQLite via its backup API, including committed WAL content."""
    with tempfile.TemporaryDirectory(prefix='mailcleaner-snapshot-') as temp:
        temp = Path(temp)
        included = []
        with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
            for name in FILES:
                source = DATA_DIR / name
                if not source.is_file():
                    continue
                if name in DATABASES:
                    snapshot = temp / name
                    with closing(sqlite3.connect(f'{source.as_uri()}?mode=ro', uri=True)) as db:
                        with closing(sqlite3.connect(snapshot)) as copy:
                            db.backup(copy)
                    source = snapshot
                if source.stat().st_size > MAX_FILE:
                    raise ValueError('A data file is too large for this backup')
                archive.write(source, name)
                included.append(name)
            if 'dashboard.sqlite3' not in included:
                raise ValueError('Dashboard data is unavailable')
            archive.writestr('manifest.json', json.dumps({'format':1, 'app_version':VERSION, 'files':included}))


def restore_to_new_directory(source):
    """Validate all entries before writing to an isolated, newly created folder."""
    with zipfile.ZipFile(source) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)) or set(names) - (set(FILES) | {'manifest.json'}):
            raise ValueError('Unexpected or duplicate backup entries')
        if 'manifest.json' not in names or 'dashboard.sqlite3' not in names:
            raise ValueError('Backup is missing required files')
        if any(info.file_size > MAX_FILE or info.is_dir() for info in infos) or sum(info.file_size for info in infos) > MAX_TOTAL:
            raise ValueError('Backup is too large')
        if archive.getinfo('manifest.json').file_size > 65536:
            raise ValueError('Backup manifest is too large')
        manifest = json.loads(archive.read('manifest.json'))
        if manifest.get('format') != 1 or set(manifest.get('files', [])) != set(names) - {'manifest.json'}:
            raise ValueError('Backup manifest does not match its contents')
        target = Path(tempfile.mkdtemp(prefix='MailCleaner-restored-', dir=DATA_DIR.parent))
        try:
            for info in infos:
                if info.filename == 'manifest.json':
                    continue
                dest = target / info.filename
                with archive.open(info) as src, os.fdopen(os.open(dest, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600), 'wb') as out:
                    shutil.copyfileobj(src, out, 1024 * 1024)
                if info.filename in DATABASES:
                    with closing(sqlite3.connect(f'{dest.as_uri()}?mode=ro', uri=True)) as db:
                        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                            raise ValueError('Database integrity check failed')
                        if info.filename == 'dashboard.sqlite3' and not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='messages'").fetchone():
                            raise ValueError('Backup is not a MailCleaner dashboard database')
            return target
        except Exception:
            shutil.rmtree(target)
            raise
