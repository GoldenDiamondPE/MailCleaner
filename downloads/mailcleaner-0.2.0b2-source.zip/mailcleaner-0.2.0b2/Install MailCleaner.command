#!/bin/zsh
set -eu
cd "${0:A:h}"
if ! command -v python3 >/dev/null 2>&1; then
  print "Install Python 3.11 or newer from python.org, then open this installer again."
  read -r "?Press Return to close."
  exit 1
fi
python3 -c 'import sys; assert sys.version_info >= (3,11), "MailCleaner requires Python 3.11 or newer"'
python3 -m venv .venv
./.venv/bin/python -m pip install .
print "Installed. Start Ollama, run ollama pull qwen3:1.7b, then open Start MailCleaner.command."
read -r "?Press Return to close."
