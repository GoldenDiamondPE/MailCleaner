"""Read release metadata without changing application or mailbox data."""
import json
import re
from urllib.request import Request, urlopen

MANIFEST_URL = 'https://goldendiamondpe.github.io/MailCleaner/downloads/release-manifest.json'
DOWNLOADS_URL = 'https://goldendiamondpe.github.io/MailCleaner/#install'


def version_key(value):
    match = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)(?:(a|b|rc)(\d+))?', value)
    if not match:
        raise ValueError('Unsupported version format')
    major, minor, patch, phase, number = match.groups()
    return (int(major), int(minor), int(patch), {None:3, 'a':0, 'b':1, 'rc':2}[phase], int(number or 0))


def check(current):
    request = Request(MANIFEST_URL, headers={'User-Agent':'MailCleaner update checker', 'Accept':'application/json'})
    with urlopen(request, timeout=5) as response:
        if response.geturl() != MANIFEST_URL:
            raise ValueError('Unexpected release location')
        payload = response.read(65537)
    if len(payload) > 65536:
        raise ValueError('Release metadata too large')
    data = json.loads(payload)
    version = data['version']
    newer = version_key(version) > version_key(current)
    return {'status':'available' if newer else 'current', 'version':version, 'url':DOWNLOADS_URL}
