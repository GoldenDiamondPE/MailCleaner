"use strict";
let state,
  csrf,
  tab = "all",
  selected = new Set(),
  activeId = null,
  offset = 0,
  refreshId = 0,
  labelsDirty = false,
  editorVersion = null,
  rowsRenderKey = "",
  actionBusy = false,
  pollTimer = null,
  detailRequest = 0;
const $ = (id) => document.getElementById(id);
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}
function notice(message) {
  $("notice").textContent = message;
  $("notice").hidden = !message;
}
async function api(path, data) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const options = { cache: "no-store", signal: controller.signal };
    if (data !== undefined)
      Object.assign(options, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-MailCleaner-CSRF": csrf,
        },
        body: JSON.stringify(data),
      });
    const response = await fetch(path, options);
    const result = await response.json();
    if (!response.ok)
      throw new Error(result.error || "The local request failed");
    return result;
  } catch (error) {
    if (error.name === "AbortError")
      throw new Error(
        "The local dashboard took too long to respond. Your saved progress is retained.",
      );
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function options(id, values, initial = "") {
  const node = $(id),
    current = node.value;
  node.replaceChildren();
  if (initial) node.append(new Option(initial, ""));
  values.forEach((v) => node.append(new Option(v, v)));
  if ([...node.options].some((o) => o.value === current)) node.value = current;
}
function visible() {
  return state ? state.rows : [];
}
function render() {
  if (!state) return;
  renderRelease();
  $("model").textContent = state.model;
  $("policy").textContent = "Policy " + state.policy;
  for (const [id, key] of [
    ["total", "total"],
    ["appliedCount", "applied"],
    ["reviewedCount", "reviewed"],
    ["reviewCount", "needs_review"],
  ])
    $(id).textContent = state.stats[key];
  $("bridgeStatus").textContent = state.bridge.status;
  if (!$("bridgeUsername").value)
    $("bridgeUsername").value = state.bridge.username;
  $("job").textContent =
    state.job.title + " · " + state.job.completed + " completed";
  $("job").parentElement.classList.toggle("running", state.job.running);
  $("stop").hidden = !state.job.running;
  for (const id of [
    "scan",
    "connect",
    "save",
    "bulkStart",
    "gmailConnect",
    "checkModel",
  ])
    $(id).disabled = state.job.running || actionBusy;
  $("errors").replaceChildren(...state.job.errors.map((e) => el("li", "", e)));
  $("errors").hidden = !state.job.errors.length;
  const rows = visible();
  $("visibleCount").textContent = state.stats.filtered;
  $("range").textContent =
    "Browse every saved message using search, filters and pages";
  $("pageInfo").textContent = state.stats.filtered
    ? `${offset + 1}–${offset + rows.length} of ${state.stats.filtered}`
    : "No matching messages";
  $("prevPage").disabled = offset === 0;
  $("nextPage").disabled = offset + rows.length >= state.stats.filtered;
  renderRuns();
  renderLabels();
  if (activeId) {
    const active = state.rows.find((r) => r.id === activeId);
    if (active)
      $("detailStatus").textContent = active.applied
        ? "Labels added · Existing labels preserved"
        : active.reviewed
          ? "Reviewed · Ready to label"
          : active.result.needs_review
            ? "Needs review · Check the email before labeling"
            : "Preview only · No mail changed";
  }
  const key = JSON.stringify([
    rows,
    [...selected],
    activeId,
    state.label_revision,
  ]);
  if (key === rowsRenderKey) {
    selection();
    return;
  }
  rowsRenderKey = key;
  const container = $("messages"),
    scrollPosition = container.scrollTop;
  container.replaceChildren();
  if (!rows.length) {
    const empty = el("div", "empty");
    empty.append(
      el("strong", "", "No messages in this view"),
      el("span", "", "Preview a batch or try a different filter."),
    );
    container.append(empty);
  }
  rows.forEach((r) => {
    const row = el("div", "row" + (activeId === r.id ? " selected" : ""));
    const check = el("input", "rowcheck");
    check.type = "checkbox";
    check.checked = selected.has(r.id);
    check.setAttribute("aria-label", "Select " + r.subject);
    check.addEventListener("change", () => {
      check.checked ? selected.add(r.id) : selected.delete(r.id);
      selection();
    });
    const open = el("button", "rowcontent");
    open.type = "button";
    open.append(el("div", "subject", r.subject || "(No subject)"));
    const meta = el("div", "rowmeta");
    meta.append(
      el("span", "sendername", r.sender),
      el("span", "", r.provider === "gmail" ? "Gmail" : "Proton"),
      el(
        "span",
        "tag " +
          (r.applied
            ? "added"
            : r.result.needs_review && !r.reviewed
              ? "review"
              : ""),
        r.applied
          ? "Labels added"
          : r.result.needs_review && !r.reviewed
            ? "Needs review"
            : r.reviewed
              ? "Reviewed"
              : "Preview",
      ),
    );
    open.append(meta);
    open.addEventListener("click", () => openMessage(r.id));
    const right = el("div", "right"),
      destination = el(
        "span",
        "tag",
        state.labels[r.provider][r.result.category],
      );
    destination.title = r.result.category + " → " + destination.textContent;
    right.append(
      destination,
      el("small", r.result.priority, r.result.priority + " priority"),
    );
    row.append(check, open, right);
    container.append(row);
  });
  container.scrollTop = scrollPosition;
  selection();
}
function selection() {
  const ids = new Set(visible().map((r) => r.id));
  $("selectAll").checked =
    ids.size > 0 && [...ids].every((id) => selected.has(id));
  $("selectAll").indeterminate =
    [...ids].some((id) => selected.has(id)) && !$("selectAll").checked;
  $("selection").textContent = selected.size + " selected";
  $("apply").textContent = selected.size
    ? "Add labels to " + selected.size + " selected"
    : "Add labels to selected";
  $("apply").disabled =
    !selected.size || selected.size > 100 || state.job.running || actionBusy;
}
async function refresh() {
  const request = ++refreshId;
  const params = new URLSearchParams({
    search: $("search").value,
    provider: $("source").value,
    category: $("category").value,
    view: tab,
    offset,
    limit: 100,
  });
  const next = await api("/api/state?" + params);
  if (request !== refreshId) return;
  state = next;
  csrf = state.csrf;
  if (!$("editCategory").options.length) {
    options("category", state.categories, "All categories");
    options("editCategory", state.categories);
    options("editType", state.message_types);
  }
  render();
}
async function action(path, data) {
  if (!state) {
    notice(
      "Wait for the local dashboard to connect before starting an action.",
    );
    return false;
  }
  if (actionBusy) return false;
  actionBusy = true;
  if (state) render();
  try {
    notice("");
    await api(path, data);
    await refresh();
    return true;
  } catch (error) {
    notice(error.message);
    return false;
  } finally {
    actionBusy = false;
    if (state) render();
    scheduleRefresh();
  }
}

async function openMessage(id) {
  const request = ++detailRequest;
  try {
    const r = await api("/api/message?id=" + id);
    if (request !== detailRequest) return;
    activeId = id;
    $("emptyDetail").hidden = true;
    $("detail").hidden = false;
    $("detailSource").textContent =
      (r.provider === "gmail" ? "GMAIL" : "PROTON") + " · " + r.account;
    $("detailSubject").textContent = r.subject || "(No subject)";
    $("detailSender").textContent = r.sender;
    $("detailDate").textContent = r.received;
    $("summary").textContent = r.result.summary;
    $("detailStatus").textContent = r.applied
      ? "Labels added · Existing labels preserved"
      : r.reviewed
        ? "Reviewed · Ready to label"
        : r.result.needs_review
          ? "Needs review · Check the email before labeling"
          : "Preview only · No mail changed";
    $("editCategory").value = r.result.category;
    $("editType").value = r.result.message_type;
    $("editPriority").value = r.result.priority;
    renderHistory(r);
    $("decisionSource").textContent = r.reviewed
      ? "Classification reviewed locally"
      : r.result.decision_source === "template"
        ? "Classification from a purpose-based rule"
        : "Classification suggested by the local model";
    $("body").textContent =
      r.body ||
      "No readable body was loaded. Inspect this message in your mail app.";
    render();
    if (matchMedia("(max-width:1100px)").matches)
      $("detail").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (e) {
    notice(e.message);
  }
}
$("scanForm").addEventListener("submit", (e) => {
  e.preventDefault();
  action("/api/scan", {
    provider: $("provider").value,
    limit: Number($("limit").value),
  });
});
$("apply").addEventListener("click", async () => {
  const ids = [...selected];
  if (await action("/api/apply", { ids })) {
    selected.clear();
    selection();
  }
});
$("stop").addEventListener("click", () => action("/api/stop", {}));
$("selectAll").addEventListener("change", () => {
  visible().forEach((r) =>
    $("selectAll").checked ? selected.add(r.id) : selected.delete(r.id),
  );
  render();
});
$("reviewForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (
    await action("/api/correct", {
      id: activeId,
      category: $("editCategory").value,
      message_type: $("editType").value,
      priority: $("editPriority").value,
    })
  )
    await openMessage(activeId);
});
$("bridgeForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  await action("/api/bridge", {
    username: $("bridgeUsername").value,
    password: $("bridgePassword").value,
    port: Number($("bridgePort").value),
    certificate_pem: $("bridgeCert").value,
  });
  $("bridgePassword").value = "";
});
let searchTimer;
for (const id of ["search", "source", "category"])
  $(id).addEventListener("input", () => {
    offset = 0;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(
      () => refresh().catch((e) => notice(e.message)),
      200,
    );
  });
document.querySelectorAll("[data-tab]").forEach((button) =>
  button.addEventListener("click", () => {
    tab = button.dataset.tab;
    offset = 0;
    document
      .querySelectorAll("[data-tab]")
      .forEach(
        (b) => (
          b.classList.toggle("active", b === button),
          b.setAttribute("aria-pressed", String(b === button))
        ),
      );
    refresh().catch((e) => notice(e.message));
  }),
);
$("prevPage").addEventListener("click", () => {
  offset = Math.max(0, offset - 100);
  refresh().catch((e) => notice(e.message));
});
$("nextPage").addEventListener("click", () => {
  offset += 100;
  refresh().catch((e) => notice(e.message));
});
$("clearSelection").addEventListener("click", () => {
  selected.clear();
  render();
});
function renderRuns() {
  const container = $("runs"),
    historyOpen = container.querySelector("details")?.open || false;
  container.replaceChildren();
  const history = el("details");
  history.open = historyOpen;
  history.append(el("summary", "", "Past inbox runs"));
  let ended = 0;
  for (const r of state.runs) {
    const row = el("div", "run"),
      info = el("div"),
      count = r.counts;
    const handled =
        (count.done || 0) + (count.review || 0) + (count.missing || 0),
      status = r.status === "cancelled" ? "Ended" : r.status;
    info.append(
      el(
        "strong",
        "",
        `#${r.id} · ${r.provider} · ${r.account} · ${r.apply_labels ? "Sort" : "Preview"} · ${status}`,
      ),
      el(
        "p",
        "",
        r.phase === "inventory"
          ? `${r.total} message IDs inventoried`
          : `${handled} / ${r.total} processed · ${count.review || 0} review · ${count.error || 0} errors · ${count.missing || 0} no longer available`,
      ),
    );
    if (r.error) info.append(el("p", "", r.error));
    const progress = el("progress");
    progress.max = Math.max(1, r.total);
    progress.value = handled;
    info.append(progress);
    const buttons = el("div", "runbuttons");
    if (["paused", "queued"].includes(r.status)) {
      const resume = el("button", "quiet", "Resume"),
        end = el("button", "quiet", "End run");
      resume.disabled = end.disabled = state.job.running;
      resume.addEventListener("click", () =>
        action("/api/bulk/resume", { id: r.id }),
      );
      end.addEventListener("click", () =>
        action("/api/bulk/end", { id: r.id }),
      );
      buttons.append(resume, end);
    }
    if (r.status === "running") {
      const pause = el("button", "quiet", "Pause");
      pause.addEventListener("click", () => action("/api/stop", {}));
      buttons.append(pause);
    }
    row.append(info, buttons);
    if (["complete", "cancelled"].includes(r.status)) {
      history.append(row);
      ended++;
    } else container.append(row);
  }
  if (!state.runs.length)
    container.append(
      el(
        "div",
        "empty",
        "No inbox runs yet. Start with a preview when you’re ready.",
      ),
    );
  if (ended) {
    history.querySelector("summary").textContent = `Past inbox runs (${ended})`;
    container.append(history);
  }
}
const labelInputs = { gmail: {}, proton: {} };
function renderLabels() {
  if (!$("labelRows").children.length) {
    state.categories.forEach((category, index) => {
      const row = el("div", "labelgrid");
      row.append(el("label", "", category));
      for (const provider of ["gmail", "proton"]) {
        const input = el("input");
        input.type = "text";
        input.spellcheck = false;
        input.dataset.provider = provider;
        input.maxLength = 100;
        input.required = true;
        input.setAttribute("aria-label", provider + " label for " + category);
        input.addEventListener("input", () => {
          labelsDirty = true;
          $("labelsStatus").textContent = "Unsaved changes";
        });
        labelInputs[provider][category] = input;
        const field = el("label", "destination-field"),
          caption = el(
            "span",
            "mobile-provider",
            provider === "gmail" ? "Gmail label / path" : "Proton label",
          );
        field.append(caption, input);
        row.append(field);
      }
      $("labelRows").append(row);
    });
  }
  if (!labelsDirty && editorVersion !== state.label_revision) {
    $("gmailRoot").value = state.labels.gmail_root;
    for (const provider of ["gmail", "proton"])
      for (const category of state.categories)
        labelInputs[provider][category].value =
          state.labels[provider][category];
    editorVersion = state.label_revision;
  }
}
$("gmailRoot").addEventListener("input", () => {
  labelsDirty = true;
  $("labelsStatus").textContent = "Unsaved changes";
});
$("labelsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const config = { gmail_root: $("gmailRoot").value, gmail: {}, proton: {} };
  for (const provider of ["gmail", "proton"])
    for (const category of state.categories)
      config[provider][category] = labelInputs[provider][category].value;
  if (
    await action("/api/labels", { settings: config, revision: editorVersion })
  ) {
    labelsDirty = false;
    editorVersion = null;
    renderLabels();
    $("labelsStatus").textContent = "Saved. Existing labels are kept.";
  }
});
$("labelsReload").addEventListener("click", () => {
  labelsDirty = false;
  editorVersion = null;
  renderLabels();
  $("labelsStatus").textContent = "Saved settings loaded";
});

$("bulkForm").addEventListener("submit", (e) => {
  e.preventDefault();
  if (labelsDirty) {
    notice(
      "Save or reload your label settings before starting a whole-inbox run.",
    );
    return;
  }
  const providers =
    $("bulkProviders").value === "both"
      ? ["gmail", "proton"]
      : [$("bulkProviders").value];
  const choice = $("bulkMode").value;
  action("/api/bulk/start", {
    providers,
    mode: choice === "saved" ? "saved" : "inbox",
    apply_labels: choice !== "preview",
  });
});

// Navigation is hash-based so each workspace view can be bookmarked.
const viewNames = {
  overview: "Overview",
  messages: "Messages",
  runs: "Inbox runs",
  labels: "Labels",
  connections: "Connections",
  help: "Help & privacy",
};
function navigate() {
  const view =
    location.hash.slice(1) in viewNames ? location.hash.slice(1) : "overview";
  document.querySelectorAll("[data-view]").forEach((node) => {
    node.hidden = node.dataset.view !== view;
  });
  document.querySelectorAll("[data-nav]").forEach((node) => {
    const active = node.dataset.nav === view;
    node.classList.toggle("active", active);
    if (active) node.setAttribute("aria-current", "page");
    else node.removeAttribute("aria-current");
  });
  $("viewName").textContent = viewNames[view];
  document.title = "MailCleaner · " + viewNames[view];
  window.scrollTo({ top: 0 });
}
let modelInitialized = false;
function renderRelease() {
  $("updateLink").hidden = state.update.status !== "available";
  if (state.update.status === "available") $("updateLink").textContent = "Update " + state.update.version + " available ↗";
  if (!modelInitialized) {
    $("modelProvider").value = state.backend;
    $("modelEndpoint").value = state.model_endpoint;
    modelInitialized = true;
  }
  $("modelSelect").disabled = state.job.running || actionBusy;
  $("modelDiscover").disabled = state.job.running || actionBusy;
  $("version").textContent = "v" + state.version + " · Public beta";
  $("backend").textContent =
    state.backend === "lmstudio" ? "LM Studio" : "Ollama";
  $("gmailStatus").textContent = state.gmail.status;
  $("modelStatus").textContent = state.model + " · " + state.model_status;
  $("modelDescription").textContent =
    "Classification uses " +
    $("backend").textContent +
    ". A local tunnel can connect to your PC over Tailscale.";
  for (const [id, text, ready] of [
    ["gmailQuick", state.gmail.status, state.gmail.status === "Connected"],
    [
      "protonQuick",
      state.bridge.configured ? "Connected" : "Not connected",
      state.bridge.configured,
    ],
    ["modelQuick", state.model_status, state.model_status === "Ready"],
  ]) {
    $(id).textContent = text;
    $(id).classList.toggle("ready", ready);
  }
  $("gmailImport").disabled = state.job.running || actionBusy;
  $("navReview").textContent = state.stats.needs_review;
  $("navReview").hidden = !state.stats.needs_review;
  const labels = {
    preview: "Start inbox preview",
    inbox: "Start sorting inbox",
    saved: "Add updated labels",
  };
  $("bulkStart").textContent = labels[$("bulkMode").value];
}
function renderHistory(message) {
  const container = $("messageHistory");
  container.replaceChildren();
  const entries = [
    ...message.history.labels.map((row) => ({
      created: row.created,
      text: row.success
        ? "Added: " + row.labels.join(", ")
        : "Label attempt failed: " + row.error,
    })),
    ...message.history.reviews.map((row) => ({
      created: row.created,
      text:
        "Reviewed: " +
        row.result.category +
        " · " +
        row.result.message_type +
        " · " +
        row.result.priority,
    })),
  ].sort((a, b) => b.created.localeCompare(a.created));
  if (!entries.length)
    container.append(
      el("p", "footnote", "No label actions or corrections yet."),
    );
  for (const entry of entries) {
    const row = el("div", "history-entry", entry.text);
    row.append(el("small", "", new Date(entry.created).toLocaleString()));
    container.append(row);
  }
}
function scheduleRefresh() {
  clearTimeout(pollTimer);
  if (document.hidden) return;
  pollTimer = setTimeout(
    async () => {
      try {
        await refresh();
      } catch (error) {
        notice("Dashboard disconnected: " + error.message);
      } finally {
        scheduleRefresh();
      }
    },
    state?.job.running ? 2500 : 8000,
  );
}
window.addEventListener("hashchange", navigate);
window.addEventListener("beforeunload", (event) => {
  if (labelsDirty) {
    event.preventDefault();
    event.returnValue = "";
  }
});
document.addEventListener("visibilitychange", () => {
  clearTimeout(pollTimer);
  if (!document.hidden)
    refresh()
      .catch((error) => notice(error.message))
      .finally(scheduleRefresh);
});
document.addEventListener("keydown", (event) => {
  if (
    event.key === "/" &&
    !event.metaKey &&
    !event.ctrlKey &&
    !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)
  ) {
    event.preventDefault();
    location.hash = "messages";
    navigate();
    $("search").focus();
  }
});
document.querySelectorAll("[data-filter]").forEach((link) =>
  link.addEventListener("click", () => {
    document.querySelector('[data-tab="' + link.dataset.filter + '"]').click();
  }),
);
$("closeDetail").addEventListener("click", () => {
  detailRequest++;
  activeId = null;
  $("detail").hidden = true;
  $("emptyDetail").hidden = false;
  render();
});
$("bulkMode").addEventListener("change", () => {
  if (state) renderRelease();
});
$("gmailForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = $("gmailCredentials").files[0];
  if (!file)
    return notice("Choose your Google Desktop OAuth client JSON first.");
  if (file.size > 20000)
    return notice("The OAuth client file must be smaller than 20 KB.");
  try {
    const credentials = JSON.parse(await file.text());
    if (await action("/api/gmail/configure", { credentials })) {
      $("gmailCredentials").value = "";
      notice(
        "Client configuration saved. Choose Connect Gmail to authorize your account.",
      );
    }
  } catch {
    notice("This file could not be read as a Google OAuth JSON configuration.");
  }
});
$("gmailConnect").addEventListener("click", () =>
  action("/api/gmail/connect", {}),
);
$("checkModel").addEventListener("click", () => action("/api/model/check", {}));
$("modelDiscover").addEventListener("click", async () => {
  try {
    notice("");
    const result = await api("/api/model/list", {provider: $("modelProvider").value, endpoint: $("modelEndpoint").value});
    options("modelChoice", result.models, "Choose a model");
    if (!result.models.length) notice("No models were found on that server.");
  } catch (error) { notice("Could not find models: " + error.message); }
});
$("modelForm").addEventListener("submit", async event => {
  event.preventDefault();
  if (await action("/api/model/select", {provider: $("modelProvider").value, endpoint: $("modelEndpoint").value, model: $("modelChoice").value})) {
    notice("Model changed. Saved classifications retain their original model information.");
  }
});
$("backupRestoreForm").addEventListener("submit", async event => {
  event.preventDefault();
  const file = $("backupFile").files[0];
  if (!file || !state || state.job.running) return notice("Choose a backup and pause or finish any running job first.");
  if (file.size > 512 * 1024 * 1024) return notice("The backup must be smaller than 512 MB.");
  $("backupRestore").disabled = true;
  try {
    const response = await fetch("/api/backup/restore", {method:"POST", headers:{"Content-Type":"application/zip", "X-MailCleaner-CSRF":csrf}, body:file});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Backup could not be restored");
    $("backupRestorePath").textContent = result.directory;
    const quoted = "'" + result.directory.replace(/'/g, "'\\''") + "'";
    $("backupRestoreCommand").textContent = "MAILCLEANER_DATA_DIR=" + quoted + " ./.venv/bin/python dashboard.py --open";
    $("backupRestoreResult").hidden = false;
    $("backupFile").value = "";
  } catch (error) { notice(error.message); }
  finally { $("backupRestore").disabled = false; }
});
navigate();
refresh()
  .catch((error) => notice(error.message))
  .finally(scheduleRefresh);
