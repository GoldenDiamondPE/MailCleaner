"""Local preview/review/label dashboard. No delete, move, archive or send routes."""
import argparse
import hmac
import json
import os
import secrets
import threading
import platform
import signal
import webbrowser
import tempfile
import shutil
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files as package_files
from pathlib import Path
from typing import get_args
from urllib.parse import urlsplit, parse_qs

import classifier as c
import mail_store as store
from mailboxes import GmailMailbox, ProtonMailbox
from mail_actions import category_names
import label_settings
import bulk_store
from bulk_runner import Runner, apply_one
from predictor import predict
from runtime_paths import VERSION, data_path, private_write, instance_lock
from gmail_client import get_gmail_service
from local_backend import PROVIDER, list_models, make_client
import update_check
import backup_data

ROOT = Path(__file__).resolve().parent


class Service:
    def __init__(self):
        self.lock = threading.RLock()
        self.bridge = {}
        self.bridge_status = 'Not connected'
        self.cancelled = threading.Event()
        self.worker = None
        self.model_status = 'Not checked'
        self.update = {'status':'checking', 'version':'', 'url':update_check.DOWNLOADS_URL}
        self.gmail_status = 'Account saved' if data_path('token.json').exists() else 'Not connected'
        self.job = {'running':False, 'title':'Ready', 'completed':0, 'errors':[], 'ids':[]}
        with store.connect() as db:
            saved = db.execute("SELECT value FROM settings WHERE key='model_config'").fetchone()
        if saved:
            config = json.loads(saved[0])
            c.client = make_client(config['provider'], config['endpoint'])
            c.ACTIVE_PROVIDER, c.ACTIVE_ENDPOINT, c.MODEL = config['provider'], config['endpoint'], config['model']
        bulk_store.recover()
        self.bulk=Runner(self)
        threading.Thread(target=self.check_updates, daemon=True, name='mailcleaner-update-check').start()

    def check_updates(self):
        try:
            result = update_check.check(VERSION)
        except Exception:
            result = {'status':'unavailable', 'version':'', 'url':update_check.DOWNLOADS_URL}
        with self.lock:
            self.update = result

    def error(self, error):
        text = str(error)
        password = self.bridge.get('password')
        return (text.replace(password, '[hidden]') if password else text)[:300]

    def mailbox(self, provider):
        if provider == 'gmail':
            return GmailMailbox()
        if provider == 'proton':
            return ProtonMailbox(dict(self.bridge))
        raise ValueError('Choose Gmail or Proton')

    def state(self,**filters):
        rows, stats = store.list_messages(**filters)
        settings=label_settings.load()
        with self.lock:
            return {'version':VERSION, 'update':dict(self.update), 'backend':c.ACTIVE_PROVIDER, 'model':c.MODEL,
                    'model_endpoint':c.ACTIVE_ENDPOINT,
                    'model_status':self.model_status, 'policy':c.PROMPT_VERSION, 'categories':get_args(c.Category),
                    'gmail':{'configured':data_path('credentials.json').exists(), 'status':self.gmail_status},
                    'message_types':get_args(c.MessageType), 'rows':rows, 'stats':stats,
                    'labels':settings,'label_revision':label_settings.revision(settings),'runs':bulk_store.runs(),
                    'job':{**self.job, 'errors':list(self.job['errors']), 'ids':list(self.job['ids'])},
                    'bridge':{'configured':bool(self.bridge), 'status':self.bridge_status,
                              'username':self.bridge.get('username','')}}

    def start(self, title, operation):
        with self.lock:
            if self.job['running']:
                raise ValueError('A job is already running; wait or stop it first')
            self.cancelled.clear()
            self.job = {'running':True, 'title':title, 'completed':0, 'errors':[], 'ids':[]}
        def run():
            try:
                operation()
            except Exception as error:
                with self.lock:
                    self.job['errors'].append(self.error(error))
            finally:
                with self.lock:
                    self.job['running'] = False
                    status = 'Stopped' if self.cancelled.is_set() else 'Finished with errors' if self.job['errors'] else 'Finished'
                    self.job['title'] = status + ': ' + title
        self.worker = threading.Thread(target=run, daemon=True, name='mailcleaner-job')
        self.worker.start()

    def check_model(self):
        def work():
            try:
                c.client.show(c.MODEL)
                self.model_status = 'Ready'
            except Exception:
                self.model_status = 'Unavailable'
                help_text = ('Start LM Studio’s local server and load ' + c.MODEL if c.ACTIVE_PROVIDER == 'lmstudio'
                             else 'Start Ollama and run: ollama pull ' + c.MODEL)
                raise ValueError('Local model unavailable. ' + help_text) from None
        self.start('Check local model', work)

    def model_options(self, data):
        return list_models(data.get('provider'), data.get('endpoint', ''))

    def select_model(self, data):
        with self.lock:
            if self.job['running']:
                raise ValueError('Pause or finish the current job before changing models')
            provider, endpoint, model = data.get('provider'), data.get('endpoint', '').rstrip('/'), data.get('model')
            if not isinstance(model, str) or not model or len(model) > 255:
                raise ValueError('Select an available model')
            if model not in list_models(provider, endpoint):
                raise ValueError('Selected model is not available on this server')
            new_client = make_client(provider, endpoint)
            config = {'provider':provider, 'endpoint':endpoint, 'model':model}
            with store.connect() as db:
                db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('model_config',?)", (json.dumps(config),))
            c.client, c.ACTIVE_PROVIDER, c.ACTIVE_ENDPOINT, c.MODEL = new_client, provider, endpoint, model
            self.model_status = 'Ready'

    def configure_gmail(self, data):
        with self.lock:
            if self.job['running']:
                raise ValueError('Wait for the current job before changing Gmail settings')
            if data_path('token.json').exists():
                raise ValueError('An account is already saved. Use its existing OAuth client configuration.')
            config = data.get('credentials')
            if not isinstance(config, dict) or not isinstance(config.get('installed'), dict):
                raise ValueError('Choose the Google OAuth JSON for a Desktop app, not a web application')
            installed = config['installed']
            # Do not let an imported configuration redirect credentials to an
            # arbitrary authorization or token server.
            if (installed.get('auth_uri') != 'https://accounts.google.com/o/oauth2/auth'
                    or installed.get('token_uri') != 'https://oauth2.googleapis.com/token'
                    or not str(installed.get('client_id','')).endswith('.apps.googleusercontent.com')
                    or not installed.get('client_secret')):
                raise ValueError('The Desktop OAuth client must use Google authorization and token endpoints')
            private_write(data_path('credentials.json'), json.dumps({'installed':installed}))

    def connect_gmail(self):
        if not data_path('credentials.json').exists():
            raise ValueError('Import your Google Desktop OAuth client JSON first')
        def work():
            self.gmail_status = 'Connecting in browser…'
            service = None
            try:
                service = get_gmail_service()
                service.users().getProfile(userId='me').execute()
                self.gmail_status = 'Connected'
            except Exception:
                self.gmail_status = 'Connection needs attention'
                raise ValueError('Gmail connection failed or timed out. Check the OAuth client, test-user access, and browser authorization, then try again.') from None
            finally:
                if service is not None:
                    service.close()
        self.start('Connect Gmail', work)

    def scan(self, provider, limit):
        if provider not in {'gmail','proton'} or type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('Choose a provider and a batch size between 1 and 100')
        def work():
            c.client.show(c.MODEL)
            mailbox = self.mailbox(provider)
            try:
                failed = 0
                for message in mailbox.scan(limit, store.known(provider, mailbox.account)):
                    if self.cancelled.is_set():
                        break
                    try:
                        result=predict(message)
                        row_id = store.save(message, result, c.model_identity(), c.PROMPT_VERSION)
                        with self.lock:
                            self.job['ids'].append(row_id)
                            self.job['completed'] += 1
                        failed = 0
                    except Exception as error:
                        failed += 1
                        with self.lock:
                            self.job['errors'].append(self.error(error))
                        if failed >= 3:
                            break
            finally:
                mailbox.close()
        self.start(f'Preview {limit} {provider} messages', work)

    def apply(self, ids):
        if not isinstance(ids,list) or not 1 <= len(ids) <= 100 or any(type(i) is not int for i in ids):
            raise ValueError('Select between 1 and 100 messages')
        ids = list(dict.fromkeys(ids))
        rows = [store.get(i) for i in ids]  # Validate the whole selection first.
        def work():
            current_rows = [store.get(i) for i in ids]
            mailboxes = {}
            try:
                for row in current_rows:
                    if self.cancelled.is_set():
                        break
                    result = c.EmailClassification.model_validate_json(row['result'])
                    categories = [result.category]
                    if (result.needs_review or result.category == 'Account Security') and result.category != 'Other / Review':
                        categories.append('Other / Review')
                    names = category_names(categories)
                    try:
                        if row['provider'] not in mailboxes:
                            mailboxes[row['provider']] = self.mailbox(row['provider'])
                        labels=apply_one(row,mailboxes[row['provider']])
                        with self.lock:
                            self.job['completed'] += 1
                            self.job['ids'].append(row['id'])
                    except Exception as error:
                        text = self.error(error)
                        with self.lock:
                            self.job['errors'].append(text)
                        break  # Preserve completed actions; stop a failing write batch.
            finally:
                for mailbox in mailboxes.values():
                    mailbox.close()
        self.start(f'Add labels to {len(rows)} messages', work)

    def save_labels(self,data):
        # Mapping edits are atomic and can be made while sorting. Completed
        # items in active runs are rechecked; changed names are added, not moved.
        if set(data)=={'settings','revision'}:label_settings.save(data['settings'],data['revision'])
        else:label_settings.save(data)

    def end_run(self,run_id):
        with self.lock:
            if self.job['running']:raise ValueError('Pause the current job first')
            bulk_store.get(run_id)
            bulk_store.update(run_id,status='cancelled',error='Ended by user; all saved history retained')

    def correct(self, data):
        with self.lock:
            if self.job['running']:
                raise ValueError('Wait for the current job before editing a classification')
            row = store.get(data['id'])
            previous = c.EmailClassification.model_validate_json(row['result'])
            updates = {k:data[k] for k in ('category','message_type','priority')}
            result = c.EmailClassification.model_validate({**previous.model_dump(), **updates,
                                                          'needs_review':updates['category']=='Account Security'})
            store.correct(row['id'], result)

    def configure_bridge(self, data):
        with self.lock:
            if self.job['running']:
                raise ValueError('Wait for the current job before changing Bridge settings')
            config = {k:data.get(k) for k in ('username','password','port')}
            config['port'] = config['port'] or 1143
            certificate = data.get('certificate_pem','').strip()
            if 'PRIVATE KEY' in certificate:
                raise ValueError('Use the public Bridge certificate only, not its private key')
            if certificate:
                config['certificate_pem'] = certificate
            def connect():
                try:
                    mailbox = ProtonMailbox(config)
                except Exception as error:
                    raise RuntimeError(str(error).replace(config.get('password') or '\x00', '[hidden]')) from None
                mailbox.close()
                with self.lock:
                    self.bridge = config  # Password stays in memory, never SQLite/logs.
                    self.bridge_status = 'Connected · Inbox read-only'
            self.start('Connect Proton Bridge', connect)


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def log_message(self, *args):
        pass  # No request bodies, mailbox details or credentials in access logs.

    def allowed_host(self):
        port = self.server.server_address[1]
        return self.headers.get('Host') in {f'127.0.0.1:{port}', f'localhost:{port}'}

    def send(self, data, code=200, mime='application/json; charset=utf-8', attachment=False):
        body = data if isinstance(data,bytes) else json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if attachment:
            self.send_header('Content-Disposition','attachment; filename="mailcleaner-reviewed-cases.json"')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.allowed_host():
            return self.send({'error':'Local access only'},403)
        path = urlsplit(self.path)
        try:
            if path.path == '/api/state':
                q=parse_qs(path.query)
                filters={k:q.get(k,[''])[0] for k in ('search','provider','category')}
                filters.update(view=q.get('view',['all'])[0],offset=int(q.get('offset',['0'])[0]),limit=int(q.get('limit',['100'])[0]))
                return self.send({**self.server.service.state(**filters), 'csrf':self.server.csrf})
            if path.path == '/api/message':
                row = store.get(int(parse_qs(path.query)['id'][0]))
                row['result'] = json.loads(row['result'])
                row['body'] = c.clean_email_text(row['body'])
                row['history'] = store.history(row['id'])
                return self.send(row)
            if path.path == '/api/diagnostics':
                # Deliberately omit accounts, messages, paths, errors and secrets.
                return self.send({'version':VERSION, 'python':platform.python_version(),
                                  'system':platform.system(), 'architecture':platform.machine(),
                                  'backend':PROVIDER, 'model':c.MODEL, 'policy':c.PROMPT_VERSION,
                                  'local_only':True, 'label_only':True})
            if path.path == '/api/export':
                return self.send(store.export_corrections(),attachment=True)
            if path.path == '/api/backup':
                service = self.server.service
                with service.lock:
                    if service.job['running']:
                        return self.send({'error':'Pause or finish the current job first'},409)
                    with tempfile.TemporaryFile() as output:
                        backup_data.create_backup(output)
                        length = output.tell()
                        output.seek(0)
                        self.send_response(200)
                        self.send_header('Content-Type','application/zip')
                        self.send_header('Content-Disposition','attachment; filename="mailcleaner-private-backup.zip"')
                        self.send_header('Content-Length', str(length))
                        self.send_header('Cache-Control','no-store')
                        self.send_header('X-Content-Type-Options','nosniff')
                        self.end_headers()
                        shutil.copyfileobj(output, self.wfile, 1024 * 1024)
                        return
            files = {'/':('index.html','text/html; charset=utf-8'), '/app.js':('app.js','text/javascript; charset=utf-8'),
                     '/style.css':('style.css','text/css; charset=utf-8'), '/icon.svg':('icon.svg','image/svg+xml')}
            if path.path not in files:
                return self.send({'error':'Not found'},404)
            filename, mime = files[path.path]
            source_asset = ROOT/'web'/filename
            content = source_asset.read_bytes() if source_asset.is_file() else package_files('mailcleaner_assets').joinpath(filename).read_bytes()
            return self.send(content,mime=mime)
        except (ValueError, KeyError, IndexError):
            return self.send({'error':'Message not found'},404)
        except Exception:
            return self.send({'error':'The local request could not be completed. Restart the dashboard if it persists.'},500)

    def do_POST(self):
        origin = self.headers.get('Origin')
        if not self.allowed_host() or origin != 'http://' + self.headers.get('Host','') or not hmac.compare_digest(
            self.headers.get('X-MailCleaner-CSRF',''), self.server.csrf
        ):
            return self.send({'error':'Invalid local request'},403)
        try:
            length = int(self.headers.get('Content-Length','0'))
            if self.path == '/api/backup/restore':
                if not 1 <= length <= backup_data.MAX_TOTAL:
                    raise ValueError('Backup size is invalid')
                service = self.server.service
                with service.lock:
                    if service.job['running']:
                        raise ValueError('Pause or finish the current job first')
                    with tempfile.TemporaryFile() as upload:
                        remaining = length
                        while remaining:
                            chunk = self.rfile.read(min(1024 * 1024, remaining))
                            if not chunk:
                                raise ValueError('Backup upload was incomplete')
                            upload.write(chunk)
                            remaining -= len(chunk)
                        upload.seek(0)
                        try:
                            target = backup_data.restore_to_new_directory(upload)
                        except (zipfile.BadZipFile, json.JSONDecodeError, OSError):
                            raise ValueError('Backup could not be validated') from None
                return self.send({'ok':True, 'directory':str(target)})
            if not 1 <= length <= 32768:
                raise ValueError('Request size is invalid')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data,dict):
                raise ValueError('Expected a JSON object')
            service = self.server.service
            if self.path == '/api/scan':
                service.scan(data.get('provider'),data.get('limit'))
            elif self.path == '/api/apply':
                service.apply(data.get('ids'))
            elif self.path == '/api/correct':
                service.correct(data)
            elif self.path == '/api/bridge':
                service.configure_bridge(data)
            elif self.path == '/api/gmail/configure':
                service.configure_gmail(data)
            elif self.path == '/api/gmail/connect':
                service.connect_gmail()
            elif self.path == '/api/model/check':
                service.check_model()
            elif self.path == '/api/model/list':
                return self.send({'models':service.model_options(data)})
            elif self.path == '/api/model/select':
                service.select_model(data)
            elif self.path == '/api/stop':
                service.cancelled.set()
            elif self.path == '/api/labels':
                service.save_labels(data)
            elif self.path == '/api/bulk/start':
                service.bulk.start(data.get('providers'),data.get('mode','inbox'),data.get('apply_labels',True))
            elif self.path == '/api/bulk/resume':
                if type(data.get('id')) is not int:raise ValueError('Invalid run ID')
                service.bulk.resume(data['id'])
            elif self.path == '/api/bulk/end':
                if type(data.get('id')) is not int:raise ValueError('Invalid run ID')
                service.end_run(data['id'])
            else:
                return self.send({'error':'Not found'},404)
            return self.send({'ok':True})
        except (ValueError, KeyError, TypeError) as error:
            return self.send({'error':self.server.service.error(error)},400)
        except Exception as error:
            return self.send({'error':self.server.service.error(error)},500)


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--open',action='store_true',help='Open the local dashboard in your browser')
    parser.add_argument('--version',action='version',version='MailCleaner '+VERSION)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error('Port must be between 1 and 65535')
    try:
        server = ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    except PermissionError:
        parser.exit(1, 'This environment does not allow a local dashboard server.\n')
    except OSError:
        parser.exit(1, f'Port {args.port} is unavailable. Open the existing dashboard or choose a different --port.\n')
    def interrupt(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupt)
    try:
        with instance_lock():
            server.service = Service()
            server.csrf = secrets.token_urlsafe(32)
            print(f'MailCleaner: http://127.0.0.1:{args.port} · {c.MODEL} · labels only',flush=True)
            if args.open:
                webbrowser.open(f'http://127.0.0.1:{args.port}')
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                server.service.cancelled.set()
                if server.service.worker:
                    # The worker checks cancellation between messages. Wait for the
                    # current operation/checkpoint rather than cutting off a label write.
                    print('Saving progress; waiting for the current operation to finish…',flush=True)
                    server.service.worker.join()
                server.server_close()
    except RuntimeError as error:
        server.server_close()
        parser.exit(1, str(error) + '\n')


if __name__ == '__main__':
    main()
