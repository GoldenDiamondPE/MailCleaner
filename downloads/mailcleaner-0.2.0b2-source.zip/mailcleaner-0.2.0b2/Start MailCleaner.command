#!/bin/zsh
cd -- "$(dirname -- "$0")" || exit 1
if [[ ! -x ./.venv/bin/python ]]; then
  print "Run Install MailCleaner.command first, then open this launcher again."
  read -r "?Press Return to close."
  exit 1
fi
print "Leave this window open while MailCleaner is running."
exec ./.venv/bin/python dashboard.py --open
