# Release candidate 0.2.0b1

## Included

- Redesigned local dashboard with distinct Overview, Messages, Inbox runs,
  Labels, Connections, and Help views.
- Local Gmail OAuth client import/authorization, model availability control,
  clearer Bridge setup, and per-message review/label audit history.
- Python wheel and console entry point with bundled static assets.
- Private per-user data directories for fresh installs; existing checkout data
  remains in place. Atomic private credential writes.
- Reduced repeated SQLite setup and run-history queries; polling pauses when
  hidden and backs off when idle. Request timeouts and stale-response handling.
- Loopback inference enforcement, per-data-directory instance locking,
  clearer job errors, graceful job shutdown,
  private technical diagnostics, and source allowlist packaging.
- Separate public static page with synthetic sample content and download links.

## Validation state

The user requested feature and release work with additional tests deferred.
No new regression suite, model benchmark, or live email sorting is part of this
release preparation. Packaging and visual inspection are not a substitute for
release validation. Treat the artifacts as beta candidates, not certified
production binaries. The prior project's validation reports are private and
are deliberately excluded from public artifacts.

## Before broader public release

1. Run regression suites and fresh install/upgrade checks on supported Python
   versions and Apple silicon. Exercise first-time OAuth, expired/revoked tokens,
   Bridge certificate changes, stopped/restarted jobs, and offline recovery.
2. Review the Gmail OAuth branding and restricted scope verification path. The
   current beta requires each user to provide a Desktop OAuth client. A polished
   public authorization flow is not yet verified or bundled.
3. Pick a project license and add a maintainer, support contact, and issue/report
   destination. Review dependency and model notices before redistributing them.
4. Resolve dependency versions into a reviewed, hashed lock for each supported
   Python/platform combination; scan dependencies before a tagged release.
5. Produce and validate a signed/notarized Mac installer if a consumer one-click
   application is the release target. This Python build is neither signed nor
   notarized. Windows and Linux currently have no validated support claim.
6. Select the public hosting destination and review the static site plus source
   artifact. Publish only the allowlisted artifacts, never the project folder,
   credentials, databases, private reports, or a live dashboard port.
7. Verify the release checksums and complete independent safety/privacy review.

Gmail's `gmail.modify` scope is restricted; applicable verification requirements
and exceptions are described in [Google's official guidance](https://developers.google.com/identity/protocols/oauth2/production-readiness/restricted-scope-verification).
MailCleaner does not claim to be an officially supported Proton client.

## Updating an existing checkout

Stop the dashboard, retain your private data, and replace source files only.
The existing data path is detected automatically. Saved corrections and labels
are not reset; interrupted runs resume from durable checkpoints. After a restart,
reconnect Bridge because its password is intentionally not persisted. Keep a
private backup of application data before future schema migrations.
