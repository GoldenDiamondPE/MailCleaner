#!/bin/zsh
cd -- "$(dirname -- "$0")" || exit 1
if [[ ! -x ./.venv/bin/python ]]; then
  print "Run Install MailCleaner.command first."
  read -r "?Press Return to close."
  exit 1
fi
print "Leave this window open while accessing MailCleaner from your tailnet."
exec ./.venv/bin/python dashboard.py --open --tailscale --serve
