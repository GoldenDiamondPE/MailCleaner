@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto dependencies

where py >nul 2>&1
if errorlevel 1 goto use_python
py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))"
if errorlevel 1 goto python_missing
py -3 -m venv .venv
if errorlevel 1 goto failed
goto dependencies

:use_python
python -c "import sys; sys.exit(sys.version_info < (3, 11))"
if errorlevel 1 goto python_missing
python -m venv .venv
if errorlevel 1 goto failed

:dependencies
".venv\Scripts\python.exe" -c "import sys; sys.exit(sys.version_info < (3, 11))"
if errorlevel 1 goto python_missing
".venv\Scripts\python.exe" -c "import ollama, httpx, pydantic, googleapiclient, google_auth_oauthlib" >nul 2>&1
if not errorlevel 1 goto start
echo Installing MailCleaner dependencies into .venv...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed

:start
echo Starting MailCleaner. Leave this window open while it runs.
".venv\Scripts\python.exe" dashboard.py --open %*
if errorlevel 1 goto failed
exit /b 0

:python_missing
echo MailCleaner needs Python 3.11 or newer. Install it and try again.
:failed
echo MailCleaner could not start. Read the message above for details.
pause
exit /b 1
