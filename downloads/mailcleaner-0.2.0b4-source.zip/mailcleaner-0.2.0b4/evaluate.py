"""Read-only local model benchmark. Never connects to Gmail or changes labels."""
import argparse
import importlib
import json
import hashlib
import os
import time
from collections import Counter
from pathlib import Path
from typing import get_args


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, default=Path(__file__).with_name("evaluation_cases.json"))
    parser.add_argument("--module", default="classifier")
    parser.add_argument("--output", type=Path, help="Write a private JSONL result file; existing files are never overwritten")
    args = parser.parse_args()
    classifier = importlib.import_module(args.module)
    cases = json.loads(args.cases.read_text())
    if not cases or len({case['id'] for case in cases}) != len(cases):
        raise ValueError('Cases must be nonempty and have unique IDs')
    # A list declares acceptable labels BEFORE inference for ambiguous evidence.
    # Ambiguous cases are reported separately rather than silently removed.
    for case in cases:
        for key in ('sender', 'subject', 'body'):
            if not isinstance(case[key], str):
                raise ValueError(f'{case["id"]}: {key} must be text')
        if not any(key in case for key in ('category', 'message_type', 'priority')):
            raise ValueError(f'{case["id"]}: no reference labels')
        for key, allowed in {'category': get_args(classifier.Category),
                             'message_type': get_args(classifier.MessageType),
                             'priority': ('high', 'medium', 'low')}.items():
            if key in case:
                values = case[key] if isinstance(case[key], list) else [case[key]]
                if not values or any(value not in allowed for value in values):
                    raise ValueError(f'{case["id"]}: invalid {key} reference')
    output = (os.fdopen(os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w')
              if args.output else None)
    def emit(record):
        line = json.dumps(record, ensure_ascii=False)
        print(line, flush=True)
        if output:
            output.write(line + '\n')
            output.flush()
    emit({'kind': 'metadata', 'model': classifier.MODEL, 'prompt': classifier.PROMPT_VERSION,
          'provider': classifier.PROVIDER,
          'cases_sha256': hashlib.sha256(args.cases.read_bytes()).hexdigest()})
    correct = failed = 0
    clear_correct = clear_total = 0
    matched = Counter()
    totals = Counter()
    confusion = Counter()
    category_support = Counter()
    category_predicted = Counter()
    category_correct = Counter()
    start = time.perf_counter()
    for case in cases:
        request_started = time.perf_counter()
        reference_category = case.get('category') if isinstance(case.get('category'), str) else None
        if reference_category:
            category_support[reference_category] += 1
        ambiguous = case.get('ambiguous', any(isinstance(case.get(k), list) and len(case[k]) > 1
                                            for k in ('category', 'message_type', 'priority')))
        clear_total += not ambiguous
        try:
            result = classifier.classify_email(case["sender"], case["subject"], case["body"])
            if reference_category:
                category_predicted[result.category] += 1
                if result.category == reference_category:
                    category_correct[reference_category] += 1
            fields = [k for k in ("category", "message_type", "priority") if k in case]
            matches = {k: getattr(result, k) in (case[k] if isinstance(case[k], list) else [case[k]]) for k in fields}
            ok = all(matches.values())
            correct += ok
            clear_correct += ok and not ambiguous
            for key in fields:
                totals[key] += 1
                matched[key] += matches[key]
            if not matches.get('category', True):
                confusion[(str(case['category']), result.category)] += 1
            emit({"id": case["id"], "match": ok, 'ambiguous': ambiguous, 'fields': matches,
                              "expected": {k: case[k] for k in fields},
                              "actual": {k: getattr(result, k) for k in fields},
                              'needs_review': result.needs_review, 'decision_source': result.decision_source,
                              'seconds': round(time.perf_counter() - request_started, 3)})
        except Exception as error:
            failed += 1
            # Failed inference is incorrect for every requested field.
            for key in ('category', 'message_type', 'priority'):
                totals[key] += key in case
            emit({"id": case["id"], "error": str(error)})
    emit({'kind': 'summary', "model": classifier.MODEL, "prompt": classifier.PROMPT_VERSION,
                      "matched": correct, "total": len(cases), "errors": failed,
                      'clear_matched': clear_correct, 'clear_total': clear_total,
                      'field_matches': dict(matched), 'field_totals': dict(totals),
                      'category_metrics': {category: {
                          'support': category_support[category], 'predicted': category_predicted[category],
                          'correct': category_correct[category],
                          'precision': round(category_correct[category] / category_predicted[category], 4) if category_predicted[category] else None,
                          'recall': round(category_correct[category] / category_support[category], 4) if category_support[category] else None,
                      } for category in sorted(set(category_support) | set(category_predicted))},
                      'category_confusions': [{'expected': a, 'actual': b, 'count': n} for (a, b), n in confusion.most_common()],
                      "seconds": round(time.perf_counter() - start, 2)})
    if output:
        output.close()
    return int(correct != len(cases))


if __name__ == "__main__":
    raise SystemExit(main())
