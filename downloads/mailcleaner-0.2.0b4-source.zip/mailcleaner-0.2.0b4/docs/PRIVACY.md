# Privacy and data handling

MailCleaner runs a dashboard on loopback and sends email evidence only to a
loopback inference server (which may be an SSH tunnel to another computer).
It connects directly to Gmail via Google's API and
to Proton Mail Bridge on the same computer. It does not include analytics,
advertising, a developer-operated inbox server, or a hosted AI provider.

The local SQLite database contains message identifiers, accounts, senders,
subjects, email bodies/previews, classifications, human corrections, label
actions, settings, and run checkpoints. It is not encrypted by the application.
OAuth client configuration and Gmail refresh tokens are stored as private local
files. Bridge passwords remain in process memory. The user is responsible for
protecting the computer, disk encryption, backups, and inference software.
MailCleaner checks the public GitHub Pages release manifest at startup; GitHub
receives a normal web request, including your network address. The request
does not contain mail, account details, or credentials. A failed check does
not prevent the app from running.

Reviewed-example exports contain email text and should not be posted publicly.
Technical-detail exports contain version, OS, architecture, model, backend, and
policy identifiers, excluding mailbox content, account details, paths, and
credentials. MailCleaner's HTTP access logger is disabled.

The optional private-backup ZIP contains message text, settings, and Gmail
authorization files. MailCleaner does not encrypt this ZIP; keep it on
encrypted storage, and never publish or share it. A restore creates a separate
data folder and can be selected for the next launch. It does not merge with
the existing database. Proton Bridge passwords remain in memory and are not
included. Bridge certificates may need to be replaced when moving computers.

The optional Tailscale Serve mode restricts the dashboard to the configured
Tailscale account and keeps the backend on loopback. Local programs on the
computer are trusted. It is not a public multi-user hosting service; do not
expose it through Tailscale Funnel or another public reverse proxy.

There is currently no in-app retention scheduler or data deletion tool. To stop
using MailCleaner, stop the process, revoke its Google authorization from your
Google account, then manage local files and backups yourself. This does not
remove any mail or provider labels. Do not delete local files during an active
run. Deleting local history loses progress and corrections.

The public product page is separate static content without mailbox access or
MailCleaner analytics. A hosting provider may collect ordinary web access logs;
review its policies before publishing. External documentation links contact
their destination when opened. Python dependencies and model downloads contact
their respective distributors during installation.

Public distribution still needs a named maintainer/contact, a selected project
license, review against Google's user data requirements, and release validation.
This document describes the implementation, not certification or an independent
security audit.
