# Prioritized follow-up

## Release blockers

- Fresh-user setup and upgrade validation, including mailbox preservation checks.
- Gmail public OAuth verification and a clearer revocation/reconnection flow.
- Selected license, maintainer identity, support channel, dependency notices.
- Signed/notarized Mac distribution with a reliable installer and upgrade path.

## Accuracy and review

- A consented, held-out evaluation set with per-category precision/recall,
  explicit critical-error reporting, and separate rule/model results. Keep
  real messages private and prevent tuning examples from inflating scores.
- Optional local escalation for ambiguous mail, measured against the 1.7B
  baseline before enabling; retain a review-first default.
- User-defined category semantics with schema/version migrations. Renaming
  current destinations is intentionally separate from defining a new category.
- Review filters for security, unknown senders, stale policy results, and label
  write failures; bulk correction preview before applying changes.

## Reliability and performance

- Bounded retries with jitter, quota-aware Gmail reads, and a user-visible
  connection health timestamp.
- Incremental sync after an initial inventory, avoiding repeated full scans.
- Thread-aware display, safer attachment summaries, and clearer unavailable-body
  handling; never execute or fetch email content through the dashboard.
- Optional macOS Keychain storage for Bridge credentials, requiring explicit
  opt-in and certificate lifecycle handling.
- Automated updates with verified release identity, recovery, and rollback;
  encrypted backup options and configurable local-data retention. Keep mailbox
  deletion outside this tool's scope.

## Dashboard and accessibility

- Keyboard navigation through message results, screen-reader review of live
  progress announcements, larger text preference, and color contrast audit.
- Improve completion estimates, provide per-item error retry controls, and add
  a safe local-only activity export.
- Browser-independent layout review, theme preference, and a first-launch tour.

These are planned directions, not implemented or validated features.
