# Run MailCleaner locally on your computer

MailCleaner is a Python application with a browser dashboard. It runs on your
computer; opening the dashboard does not create a hosted MailCleaner account.
Python 3.11 or newer and an Ollama or LM Studio model server are required.
Gmail and Proton authorization have their own provider requirements. Run only
one dashboard against a data directory at a time.

## macOS

From the extracted source folder, double-click `Start MailCleaner.command` if
the environment is already installed, or run `sh "Start MailCleaner.sh"` in a
terminal. The shell launcher creates `.venv` and installs dependencies the first
time. To use private Tailscale access on macOS, see `TAILSCALE.md`.

## Windows

Install Python 3.11+ and Ollama from their official providers. Extract the source
ZIP to a private folder and double-click `Start MailCleaner.bat`, or start it
from PowerShell:

```powershell
& ".\Start MailCleaner.bat"
```

It creates `.venv` and installs dependencies if they are missing. Open Ollama,
run `ollama pull qwen3:1.7b` once if needed, and leave the launcher window open.
The dashboard opens on `http://127.0.0.1:8765`. Windows launch and Tailscale
integration require real-device release validation; the Mac development machine
cannot prove Windows support.

## Linux: Ubuntu, Fedora, Arch

Install Python 3.11+, its `venv` support and pip, plus Ollama or LM Studio. On
Ubuntu, the distribution package `python3-venv` supplies the standard venv
module; Ubuntu 22.04's default Python is 3.10, so use a supported 3.11+ Python
and corresponding venv package. Fedora and Arch may have different Python
packaging and service configurations; follow your distro's official package
documentation. Then run from the extracted source directory:

```sh
sh "Start MailCleaner.sh"
```

The first launch installs dependencies inside `.venv` from the Python package
index. In another terminal, install a model once, for example
`ollama pull qwen3:1.7b`. The model and Ollama are separate downloads and have
their own licenses. Keep the launcher and model server running while sorting.

These Linux distributions have not yet been tested in this release. Desktop
browser auto-open depends on the desktop environment; if it doesn't open, use
`http://127.0.0.1:8765`. On a headless machine, the server remains loopback-only
and requires a properly authenticated tunnel to access remotely.

The source archive includes a synthetic smoke-test workflow for macOS, Windows,
Ubuntu, Fedora, and Arch. It runs only when the source and workflow are placed
in a GitHub repository with Actions enabled; uploading only the static Pages
folder does not enable it. Those CI jobs have not yet been run. They use no
mailbox credentials and must not be configured with private email data.

## Data and moving between systems

Each computer has its own database. Do not put the live SQLite database inside
a file-synchronization folder. Use the private backup and restore feature to
copy a snapshot, and do not upload the ZIP to GitHub. Restoring selects a new
data directory; it does not merge histories. Proton Bridge credentials must be
reentered and its public certificate may need to be exported again on the new
computer. File permissions and encryption are platform-dependent; the app does
not encrypt its database or backup archive.
