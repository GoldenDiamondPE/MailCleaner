"""Use exact reviewed evidence first; avoid repeated local-model work."""
import hashlib
import json
import os
import classifier as c
import mail_store as store
from local_backend import PROVIDER, LMSTUDIO_URL


def predict(message):
    message['body']=c.clean_email_text(message['body'])
    if message.get('unavailable') or not message['body']:
        return c.EmailClassification(category='Other / Review',message_type='Other',priority='medium',
            summary='No readable body was loaded; inspect in your mail app.',confidence=0.0,needs_review=True)
    reviewed=store.reviewed_result(message)
    if reviewed:return c.EmailClassification.model_validate(reviewed)
    key=hashlib.sha256(json.dumps([c.ACTIVE_PROVIDER,c.ACTIVE_ENDPOINT,c.MODEL,c.PROMPT_VERSION,c.MIN_CONFIDENCE,
        message['sender'],message['subject'],message['body']],ensure_ascii=False).encode()).hexdigest()
    cached=store.cached_prediction(key)
    if cached:return c.EmailClassification.model_validate_json(cached)
    result=c.classify_email(message['sender'],message['subject'],message['body'])
    store.cached_prediction(key,result.model_dump_json())
    return result
