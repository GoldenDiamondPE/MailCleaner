"""Release version and private, per-user application data paths."""
import os
import sys
import tempfile
import json
from contextlib import contextmanager
from pathlib import Path

VERSION = "0.2.0b4"
SOURCE_ROOT = Path(__file__).resolve().parent


def pointer_file():
    if sys.platform == 'darwin':
        root = Path.home() / 'Library/Application Support/MailCleaner'
    elif sys.platform == 'win32':
        root = Path(os.getenv('LOCALAPPDATA', Path.home() / 'AppData/Local')) / 'MailCleaner'
    else:
        root = Path(os.getenv('XDG_CONFIG_HOME', Path.home() / '.config')) / 'mailcleaner'
    return root / 'active-data.json'


def _data_directory():
    override = os.getenv("MAILCLEANER_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    pointer = pointer_file()
    if pointer.exists():
        try:
            selected = Path(json.loads(pointer.read_text())['directory']).expanduser().resolve()
            if not (selected / 'dashboard.sqlite3').is_file():
                raise ValueError('Selected data folder is missing its database')
            return selected
        except (OSError, ValueError, KeyError, TypeError) as error:
            raise RuntimeError('The selected MailCleaner data folder is unavailable. Restore access to it or set MAILCLEANER_DATA_DIR.') from error
    # Preserve an existing source installation in place. Distributed builds
    # contain neither tokens nor databases and use the per-user directory.
    if (SOURCE_ROOT / "web/index.html").is_file() and any(
        (SOURCE_ROOT / name).exists()
        for name in ("dashboard.sqlite3", "token.json", "credentials.json", "mailcleaner.db")
    ):
        return SOURCE_ROOT
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/MailCleaner"
    if sys.platform == "win32":
        return Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData/Local")) / "MailCleaner"
    return Path(os.getenv("XDG_DATA_HOME", Path.home() / ".local/share")) / "mailcleaner"


DATA_DIR = _data_directory()


def data_path(name):
    if Path(name).name != name:
        raise ValueError("Expected an application data filename")
    DATA_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    return DATA_DIR / name


def private_write(path, text):
    """Replace credentials atomically; never leave a partial token on disk."""
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".mailcleaner-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            output.write(text)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def select_data_directory(directory):
    directory = Path(directory).resolve()
    if not (directory / 'dashboard.sqlite3').is_file():
        raise ValueError('Restored data folder is unavailable')
    private_write(pointer_file(), json.dumps({'directory':str(directory)}))


@contextmanager
def instance_lock():
    """Hold an OS lock for the data directory; a crash releases it automatically."""
    fd = os.open(data_path('dashboard.lock'), os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            if os.name == 'nt':
                import msvcrt
                if os.fstat(fd).st_size == 0:
                    os.write(fd, b'0')
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise RuntimeError('MailCleaner is already using this data directory. Open its existing dashboard or stop that instance first.') from None
        yield
    finally:
        # Closing the descriptor releases the lock without unlinking the file.
        os.close(fd)
