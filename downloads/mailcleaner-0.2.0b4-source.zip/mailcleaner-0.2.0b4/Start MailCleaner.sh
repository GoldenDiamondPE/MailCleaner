#!/bin/sh
# macOS and Linux source checkout launcher. All application data stays local.
set -eu
cd -P "$(dirname "$0")"

if [ ! -x .venv/bin/python ]; then
  if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Install Python 3.11 or newer and try again.' >&2
    exit 1
  fi
  if ! python3 -c 'import sys; sys.exit(sys.version_info < (3, 11))'; then
    printf '%s\n' 'MailCleaner requires Python 3.11 or newer.' >&2
    exit 1
  fi
  printf '%s\n' 'Creating a local Python environment…'
  python3 -m venv .venv || { printf '%s\n' 'Could not create a virtual environment. Install your distribution’s Python venv package.' >&2; exit 1; }
fi

if ! .venv/bin/python -c 'import sys; sys.exit(sys.version_info < (3, 11))'; then
  printf '%s\n' 'The existing .venv needs Python 3.11 or newer. Create a new environment with a supported Python.' >&2
  exit 1
fi
if ! .venv/bin/python -c 'import ollama, httpx, pydantic, googleapiclient, google_auth_oauthlib' >/dev/null 2>&1; then
  printf '%s\n' 'Installing MailCleaner dependencies into .venv…'
  .venv/bin/python -m pip install -r requirements.txt
fi
printf '%s\n' 'Starting MailCleaner. Leave this terminal open while it runs.'
exec .venv/bin/python dashboard.py --open "$@"
