# Private phone access and moving a backup

MailCleaner remains bound to 127.0.0.1. On the Mac, start `Start MailCleaner Tailscale.command` with Tailscale connected. It starts the dashboard and a temporary Tailscale Serve proxy. Open the HTTPS URL printed in the launcher on a device connected to the same tailnet. Keep the launcher open. The app accepts the signed-in Tailscale identity associated with this Mac, and rejects missing or different identity headers. Tagged devices without identity headers are not supported.

Tailscale Serve must have HTTPS enabled and tailnet policy must permit the connection. Serve is private to the tailnet; never use Tailscale Funnel for the dashboard. The dashboard trusts identity headers from the local Serve proxy, so other programs running on the same Mac are also trusted. Do not expose its local port with another proxy. The launcher owns the proxy for its session; stop the app to stop serving.

The Windows PC and Mac each keep a separate MailCleaner database. Applying a Gmail or Proton label on either device changes the mailbox label on the provider, but classifications, reviews, and run history are not automatically synchronized.

To transfer a snapshot, on the PC pause any job and use Help & privacy → Download private backup. Transfer the ZIP securely to the Mac or upload it from your phone to the Mac dashboard over your private tailnet. On the Mac dashboard choose Upload backup, then Use restored data next launch. Stop and reopen the Mac app. The restored data is a separate copy; it does not merge with the Mac's existing data. The old Mac data remains in its original folder. Changes after the snapshot do not synchronize automatically.

The ZIP is not encrypted and can contain email text, account tokens, and certificates. Protect it and never commit or upload it to GitHub. Bridge passwords are not included and must be reentered. Bridge certificates can be specific to the computer: use the certificate exported by the Bridge instance on the machine where MailCleaner runs. OAuth tokens may need reauthorization. A `MAILCLEANER_DATA_DIR` environment override takes precedence over the selected restored folder.
