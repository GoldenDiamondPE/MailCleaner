"""Portable checks using synthetic data only; no mail or model server access."""
import io
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import backup_data
import classifier
import label_settings
import predictor
import update_check


class ReleaseSmokeTests(unittest.TestCase):
    def test_unreadable_email_goes_to_review(self):
        message = {'provider':'gmail','account':'test','sender':'sender@example.test',
                   'subject':'Example','body':'','unavailable':True}
        with patch('predictor.store.reviewed_result') as reviewed:
            result = predictor.predict(message)
        self.assertEqual(result.category, 'Other / Review')
        self.assertTrue(result.needs_review)
        reviewed.assert_not_called()

    def test_private_backup_restores_to_separate_folder(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / 'current'
            root.mkdir()
            db = sqlite3.connect(root / 'dashboard.sqlite3')
            try:
                db.execute('CREATE TABLE messages (body TEXT)')
                db.execute('INSERT INTO messages VALUES (?)', ('synthetic',))
                db.commit()
                output = io.BytesIO()
                with patch.object(backup_data, 'DATA_DIR', root):
                    backup_data.create_backup(output)
                    output.seek(0)
                    restored = backup_data.restore_to_new_directory(output)
                self.assertNotEqual(root, restored)
                restored_db = sqlite3.connect(restored / 'dashboard.sqlite3')
                try:
                    self.assertEqual(restored_db.execute('SELECT body FROM messages').fetchone()[0], 'synthetic')
                finally:
                    restored_db.close()
            finally:
                db.close()

    def test_label_and_version_guards(self):
        with self.assertRaises(ValueError): label_settings.validate_name('INBOX', 'gmail')
        self.assertLess(update_check.version_key('0.2.0b3'), update_check.version_key('0.2.0'))

    def test_email_text_is_not_executed(self):
        self.assertNotIn('https://example.test', classifier.clean_email_text('Hello https://example.test'))
