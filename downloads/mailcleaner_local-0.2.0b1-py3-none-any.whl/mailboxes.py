"""Bounded, non-destructive Gmail and Proton Bridge adapters."""
import base64
import email
import imaplib
import re
import ssl
from email import policy
from pathlib import Path

from gmail_client import get_gmail_service, extract_body
from mail_actions import gmail_add_labels, category_names
import label_settings


class MessageGone(RuntimeError):
    pass


class GmailMailbox:
    provider = 'gmail'

    def __init__(self):
        self.service = get_gmail_service()
        self.account = self.service.users().getProfile(userId='me').execute()['emailAddress']

    def scan(self, limit, known):
        token = None
        emitted = 0
        while True:
            args = {'userId':'me', 'q':'in:inbox -in:spam -in:trash -in:sent -in:drafts', 'maxResults':100}
            if token:
                args['pageToken'] = token
            response = self.service.users().messages().list(**args).execute()
            for item in response.get('messages', []):
                if item['id'] in known:
                    continue
                raw = self.service.users().messages().get(userId='me', id=item['id'], format='full').execute()
                headers = {h['name'].lower(): h['value'] for h in raw['payload'].get('headers', [])}
                yield {'provider':self.provider, 'account':self.account, 'remote_id':item['id'],
                       'sender':headers.get('from',''), 'subject':headers.get('subject',''),
                       'received':headers.get('date',''), 'body':extract_body(raw['payload']) or raw.get('snippet','')}
                emitted += 1
                if emitted >= limit:
                    return
            token = response.get('nextPageToken')
            if not token:
                return

    def inventory_page(self, cursor=None):
        args={'userId':'me','q':'in:inbox -in:spam -in:trash -in:drafts','maxResults':500}
        if cursor:args['pageToken']=cursor['page_token']
        response=self.service.users().messages().list(**args).execute(num_retries=3)
        token=response.get('nextPageToken')
        return [r['id'] for r in response.get('messages',[])], {'page_token':token} if token else None

    def read(self, remote_id):
        from googleapiclient.errors import HttpError
        try:
            raw=self.service.users().messages().get(userId='me',id=remote_id,format='full').execute(num_retries=3)
        except HttpError as error:
            if error.resp.status==404:raise MessageGone('Message is no longer available') from None
            raise
        headers={h['name'].lower():h['value'] for h in raw['payload'].get('headers',[])}
        return {'provider':self.provider,'account':self.account,'remote_id':remote_id,
                'sender':headers.get('from',''),'subject':headers.get('subject',''),
                'received':headers.get('date',''),'body':extract_body(raw['payload']) or raw.get('snippet','')}

    def apply(self, row, categories):
        if row['account'].casefold() != self.account.casefold():
            raise ValueError('Gmail account differs from the reviewed message account')
        if not hasattr(self,'labels'):
            response=self.service.users().labels().list(userId='me').execute(num_retries=3)
            self.labels={label['name']:label['id'] for label in response.get('labels',[])}
        return gmail_add_labels(self.service, row['remote_id'], categories,self.labels)

    def close(self):
        self.service.close()


def _quoted(value):
    if any(ord(c)<32 or ord(c)==127 for c in value):
        raise ValueError('Invalid mailbox name')
    encoded=[];chunk=[]
    def flush():
        if chunk:
            encoded.append('&'+base64.b64encode(''.join(chunk).encode('utf-16-be')).decode().rstrip('=').replace('/',',')+'-')
            chunk.clear()
    for ch in value:
        if 32<=ord(ch)<127:
            flush();encoded.append('&-' if ch=='&' else ch)
        else:chunk.append(ch)
    flush()
    return '"'+''.join(encoded).replace('\\','\\\\').replace('"','\\"')+'"'


def _mime(part):
    return {'mimeType':part.get_content_type(), 'filename':part.get_filename() or '',
            'headers':[{'name':k, 'value':str(v)} for k,v in part.items()],
            'body':{'data':base64.urlsafe_b64encode(part.get_payload(decode=True) or b'').decode()},
            'parts':[_mime(p) for p in part.iter_parts()] if part.is_multipart() else []}


class ProtonMailbox:
    provider = 'proton'

    def __init__(self, config):
        self.account = (config.get('username') or '').strip()
        password = config.get('password','')
        if not self.account or not password:
            raise ValueError('Enter the Bridge IMAP username and Bridge-generated password')
        port = int(config.get('port',1143))
        if not 1 <= port <= 65535:
            raise ValueError('Invalid Bridge port')
        from runtime_paths import data_path
        certificate = config.get('certificate_pem') or data_path('bridge-cert.pem').read_text()
        context = ssl.create_default_context(cadata=certificate)
        # Keep chain AND hostname verification; the exported Bridge certificate
        # includes 127.0.0.1. Never silently disable certificate verification.
        self.imap = imaplib.IMAP4('127.0.0.1', port, timeout=30)
        try:
            self.imap.starttls(ssl_context=context)
            self.imap.login(self.account, password)
            self._select()
        except Exception:
            self.close()
            raise

    def _select(self, readonly=True):
        status, _ = self.imap.select('INBOX', readonly=readonly)
        if status != 'OK':
            raise RuntimeError('Bridge could not open Inbox')
        _, data = self.imap.response('UIDVALIDITY')
        if not data or not data[0] or not data[0].isdigit():
            raise RuntimeError('Bridge did not return a stable UIDVALIDITY')
        self.validity = data[0].decode()
        self._writable=not readonly

    def scan(self, limit, known):
        # A single IMAP search avoids downloading message bodies for known IDs.
        status, data = self.imap.uid('SEARCH', None, 'ALL')
        if status != 'OK':
            raise RuntimeError('Bridge Inbox search failed')
        emitted = 0
        for uid in reversed((data[0] or b'').split()):
            remote_id = 'INBOX:' + self.validity + ':' + uid.decode()
            if remote_id in known:
                continue
            status, sizes = self.imap.uid('FETCH', uid, '(RFC822.SIZE)')
            if status != 'OK':
                raise RuntimeError('Bridge message size lookup failed')
            size = re.search(rb'RFC822.SIZE (\d+)', b' '.join(x for x in sizes if isinstance(x,bytes)))
            oversized = not size or int(size[1]) > 5_000_000
            request = '(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])' if oversized else '(BODY.PEEK[])'
            status, parts = self.imap.uid('FETCH', uid, request)
            if status != 'OK':
                raise RuntimeError('Bridge message read failed')
            raw = next((p[1] for p in parts if isinstance(p,tuple)), None)
            if raw is None:
                raise RuntimeError('Bridge returned no message content')
            message = email.message_from_bytes(raw, policy=policy.default)
            yield {'provider':self.provider, 'account':self.account, 'remote_id':remote_id,
                   'sender':str(message.get('from','')), 'subject':str(message.get('subject','')),
                   'received':str(message.get('date','')), 'body':'' if oversized else extract_body(_mime(message)),
                   'unavailable':oversized}
            emitted += 1
            if emitted >= limit:
                return

    def inventory_page(self,cursor=None):
        if cursor and cursor['validity']!=self.validity:
            raise ValueError('Proton Inbox identity changed; start a new inventory')
        if cursor and cursor['below']<=1:return [],None
        args=('SEARCH',None,'ALL') if not cursor else ('SEARCH',None,'UID',f"1:{cursor['below']-1}")
        status,data=self.imap.uid(*args)
        if status!='OK':raise RuntimeError('Bridge inventory search failed')
        uids=sorted({int(u) for u in (data[0] or b'').split() if u.isdigit()},reverse=True)
        if cursor:uids=[u for u in uids if u<cursor['below']]
        page=uids[:500]
        next_cursor={'validity':self.validity,'below':page[-1]} if len(uids)>500 else None
        return [f'INBOX:{self.validity}:{u}' for u in page],next_cursor

    def read(self,remote_id):
        match=re.fullmatch(r'INBOX:(\d+):(\d+)',remote_id)
        if not match or match[1]!=self.validity:raise MessageGone('Proton Inbox identity changed')
        uid=match[2]
        status,sizes=self.imap.uid('FETCH',uid,'(RFC822.SIZE)')
        size=re.search(rb'RFC822.SIZE (\d+)',b' '.join(x for x in sizes or [] if isinstance(x,bytes)))
        if status!='OK' or size is None:raise MessageGone('Message is no longer in Proton Inbox')
        oversized=int(size[1])>5_000_000
        request='(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])' if oversized else '(BODY.PEEK[])'
        status,parts=self.imap.uid('FETCH',uid,request)
        raw=next((p[1] for p in parts or [] if isinstance(p,tuple)),None)
        if status!='OK' or raw is None:raise MessageGone('Message is no longer in Proton Inbox')
        message=email.message_from_bytes(raw,policy=policy.default)
        return {'provider':self.provider,'account':self.account,'remote_id':remote_id,
                'sender':str(message.get('from','')),'subject':str(message.get('subject','')),
                'received':str(message.get('date','')),'body':'' if oversized else extract_body(_mime(message)),
                'unavailable':oversized}

    def apply(self, row, categories):
        category_names(categories)  # Validate before any IMAP mutation.
        if row['account'].casefold() != self.account.casefold():
            raise ValueError('Proton account differs from the reviewed message account')
        match = re.fullmatch(r'INBOX:(\d+):(\d+)', row['remote_id'])
        if not match or match[1] != self.validity:
            raise ValueError('Proton message identity changed; preview it again before labeling')
        # Bridge requires a writable selected session for COPY. SELECT itself
        # changes no flags; only the explicit label operation uses this mode.
        if not getattr(self,'_writable',False):self._select(readonly=False)
        if match[1] != self.validity:
            raise ValueError('Proton mailbox identity changed while selecting Inbox')
        before_flags = self._flags(match[2])
        names = []
        if not hasattr(self,'_label_folders'):self._label_folders=set()
        for leaf in label_settings.resolve('proton',categories):
            name = 'Labels/' + leaf
            if name not in self._label_folders:
                status, data = self.imap.list('""', _quoted(name))
                if status != 'OK':
                    raise RuntimeError('Could not check Proton label')
                if not any(data):
                    status, _ = self.imap.create(_quoted(name))
                    if status != 'OK':
                        status, found = self.imap.list('""', _quoted(name))
                        if status != 'OK' or not any(found):raise RuntimeError('Could not create Proton label')
                self._label_folders.add(name)
            status, details = self.imap.uid('COPY', match[2], _quoted(name))
            if status != 'OK':
                reason = ' '.join(p.decode(errors='replace') for p in details or [] if isinstance(p,bytes))
                raise RuntimeError('Could not add Proton label: ' + reason[:200])
            names.append(name)
        if self._flags(match[2]) != before_flags:
            raise RuntimeError('Source message flags changed during labeling; inspect the message before retrying')
        return names

    def _flags(self, uid):
        status, data = self.imap.uid('FETCH', uid, '(UID FLAGS)')
        raw = b' '.join(p for p in data or [] if isinstance(p,bytes))
        flags = re.search(rb'FLAGS\s+\(([^)]*)\)', raw, re.I)
        if status != 'OK' or not re.search(rb'\bUID\s+' + uid.encode() + rb'\b', raw, re.I) or flags is None:
            raise RuntimeError('Source message is no longer present in Inbox')
        return frozenset(f for f in flags[1].split() if f.lower() != b'\\recent')

    def close(self):
        # LOGOUT only: never CLOSE, STORE, MOVE, DELETE or EXPUNGE.
        try:
            self.imap.logout()
        except (OSError, imaplib.IMAP4.error, AttributeError):
            pass
