
import base64
import re
from email.message import Message

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import httplib2
from google_auth_httplib2 import AuthorizedHttp
from runtime_paths import data_path, private_write

SCOPES = ["https://www.googleapis.com/auth/gmail.modify"]
BASE_DIR = data_path("credentials.json").parent


def get_gmail_service():
    creds = None

    token_path = BASE_DIR / "token.json"
    if token_path.exists():
        creds = Credentials.from_authorized_user_file(
            str(token_path), SCOPES
        )

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                str(BASE_DIR / "credentials.json"), SCOPES
            )
            creds = flow.run_local_server(port=0, timeout_seconds=180,
                                          success_message="MailCleaner is connected. You can close this tab and return to your dashboard.")

        private_write(token_path, creds.to_json())

    http = AuthorizedHttp(creds, http=httplib2.Http(timeout=45))
    return build("gmail", "v1", http=http, cache_discovery=False)


def decode_body(data, charset="utf-8"):
    if not data:
        return ""

    raw = base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))
    try:
        return raw.decode(charset, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


def extract_body(payload):
    candidates = {"text/plain": [], "text/html": []}

    def visit(part):
        headers = {h["name"].lower(): h["value"] for h in part.get("headers", [])}
        if part.get("filename") or headers.get("content-disposition", "").lower().startswith("attachment"):
            return
        mime = part.get("mimeType", "")
        if mime == "message/rfc822":
            return  # Attached/forwarded messages are separate evidence.
        if mime in candidates:
            info = Message()
            info["content-type"] = headers.get("content-type", mime)
            body = decode_body(part.get("body", {}).get("data"), info.get_content_charset() or "utf-8")
            if body.strip():
                candidates[mime].append(body)
        for child in part.get("parts", []):
            visit(child)

    visit(payload)
    plain = "\n\n".join(candidates["text/plain"])
    rich = "\n\n".join(candidates["text/html"])
    if plain and rich:
        # Several real senders provide a plain part made only of navigation,
        # legal text or an HTML-viewing apology. Prefer their actual HTML body.
        placeholder = re.search(
            r"cannot display html|view full message:|settings are turned off|"
            r"^Chirp Home\s*-|completed an activity\.\s*Something happened|"
            r"@font-face|\.ReadMsgBody|\.ExternalClass|"
            r"^\s*(?:table|body)\s*\{[^}]*:[^}]*;",
            plain, re.I | re.M,
        )
        if placeholder:
            return rich
    return plain or rich


def get_recent_emails(service, limit=10):
    response = service.users().messages().list(
        userId="me",
        labelIds=["INBOX"],
        maxResults=limit
    ).execute()

    emails = []

    for item in response.get("messages", []):
        message = service.users().messages().get(
            userId="me",
            id=item["id"],
            format="full"
        ).execute()

        headers = {
            h["name"].lower(): h["value"]
            for h in message["payload"].get("headers", [])
        }

        body = extract_body(message["payload"])

        if not body:
            body = message.get("snippet", "")

        emails.append({
            "id": message["id"],
            "sender": headers.get("from", ""),
            "subject": headers.get("subject", ""),
            "body": body
        })

    return emails
