"""The complete Gmail write surface: add validated category labels only."""
from typing import get_args
from classifier import Category
import label_settings

PREFIX = 'MailCleaner/'


def category_names(categories):
    values = list(dict.fromkeys(categories))
    if not values or any(c not in get_args(Category) for c in values):
        raise ValueError('Unknown MailCleaner category')
    return [PREFIX + category for category in values]


def gmail_add_labels(service, message_id, categories, labels=None, destinations=None):
    category_names(categories)
    names = label_settings.resolve('gmail',categories) if destinations is None else destinations
    for name in names:label_settings.validate_name(name,'gmail')
    if labels is None:
        labels = {x['name']: x['id'] for x in service.users().labels().list(userId='me').execute().get('labels', [])}
    ids = []
    for name in names:
        if name not in labels:
            created = service.users().labels().create(userId='me', body={
                'name': name, 'labelListVisibility': 'labelShow', 'messageListVisibility': 'show'}).execute()
            labels[name] = created['id']
        ids.append(labels[name])
    if any(i.upper() in label_settings.SYSTEM for i in ids):
        raise ValueError('Refusing to modify a system folder or flag')
    service.users().messages().modify(userId='me', id=message_id, body={'addLabelIds': ids}).execute()
    return names
