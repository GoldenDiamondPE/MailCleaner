"""Local inference backends. LM Studio uses its schema-constrained chat API."""
import os
from types import SimpleNamespace
from urllib.parse import urlparse
import httpx

PROVIDER = os.getenv("MAILCLEANER_PROVIDER", "ollama").lower()
if PROVIDER not in {"ollama", "lmstudio"}:
    raise ValueError("MAILCLEANER_PROVIDER must be ollama or lmstudio")
LMSTUDIO_URL = os.getenv("LMSTUDIO_BASE_URL", "http://127.0.0.1:1234/v1").rstrip("/")
OLLAMA_URL = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")


def require_loopback(url):
    parsed = urlparse(url)
    if (parsed.scheme not in {"http", "https"}
            or parsed.hostname not in {"localhost", "127.0.0.1", "::1"}
            or parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("MailCleaner requires an HTTP inference server on this computer (127.0.0.1 or localhost)")
    return url


class LMStudioClient:
    def __init__(self, url=None):
        url = url or LMSTUDIO_URL
        require_loopback(url)
        self.http = httpx.Client(base_url=url.rstrip('/') + "/", timeout=120, trust_env=False)

    def show(self, model):
        response = self.http.get("models")
        response.raise_for_status()
        models = response.json().get("data", [])
        if not any(m["id"] == model for m in models):
            raise ValueError(f"LM Studio does not expose model {model!r}; inspect /v1/models")
        return models

    def chat(self, *, model, messages, format, options, **kwargs):
        response = self.http.post("chat/completions", json={
            "model": model, "messages": messages, "stream": False,
            "temperature": options["temperature"], "max_tokens": options["num_predict"],
            "response_format": {"type": "json_schema", "json_schema": {
                "name": "email_classification", "strict": True, "schema": format}},
        })
        response.raise_for_status()
        choices = response.json().get("choices", [])
        if not choices:
            raise ValueError("LM Studio returned no choices")
        return SimpleNamespace(message=SimpleNamespace(content=choices[0]["message"].get("content") or ""))


def list_models(provider, endpoint):
    """Discover models only through local servers or an explicit local SSH tunnel."""
    endpoint = require_loopback(endpoint).rstrip('/')
    if provider not in {'ollama', 'lmstudio'}:
        raise ValueError('Choose Ollama or LM Studio')
    with httpx.Client(base_url=endpoint + '/', timeout=10, trust_env=False) as client:
        response = client.get('api/tags' if provider == 'ollama' else 'models')
        response.raise_for_status()
        data = response.json()
    records = data.get('models', []) if provider == 'ollama' else data.get('data', [])
    return sorted({row.get('name' if provider == 'ollama' else 'id') for row in records
                   if isinstance(row, dict) and isinstance(row.get('name' if provider == 'ollama' else 'id'), str)})


def make_client(provider, endpoint):
    require_loopback(endpoint)
    if provider == 'ollama':
        from ollama import Client
        return Client(host=endpoint, timeout=120, trust_env=False)
    if provider == 'lmstudio':
        return LMStudioClient(endpoint)
    raise ValueError('Choose Ollama or LM Studio')
