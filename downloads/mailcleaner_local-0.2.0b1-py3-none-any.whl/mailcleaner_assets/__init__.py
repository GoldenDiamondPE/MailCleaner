"""Static assets packaged with the local MailCleaner dashboard."""
