"""Durable whole-inbox inventory and per-message checkpoints. No credentials."""
import json
import mail_store as store


def recover():
    with store.connect() as db:
        db.execute("UPDATE bulk_runs SET status='paused', error='Dashboard restarted; resume to continue',updated=? WHERE status IN ('running','queued')",(store.now(),))


def create(provider,account,mode='inbox',apply_labels=True):
    if provider not in {'gmail','proton'}:raise ValueError('Invalid provider')
    if mode not in {'inbox','saved'}:raise ValueError('Invalid run mode')
    with store.connect() as db:
        existing=db.execute("SELECT id FROM bulk_runs WHERE provider=? AND account=? AND status NOT IN ('complete','cancelled') ORDER BY id DESC LIMIT 1",(provider,account)).fetchone()
        if existing:raise ValueError('Resume the existing unfinished run for this mailbox')
        cursor=db.execute("INSERT INTO bulk_runs(provider,account,status,phase,mode,apply_labels,created,updated) VALUES (?,?,'queued','inventory',?,?,?,?)",(provider,account,mode,int(apply_labels),store.now(),store.now()))
        return cursor.lastrowid


def get(run_id):
    with store.connect() as db:r=db.execute('SELECT * FROM bulk_runs WHERE id=?',(run_id,)).fetchone()
    if r is None:raise ValueError('Run not found')
    return dict(r)


def update(run_id,**values):
    if not values or not set(values)<={'status','phase','error'}:raise ValueError('Invalid run fields')
    with store.connect() as db:
        db.execute('UPDATE bulk_runs SET '+','.join(k+'=?' for k in values)+',updated=? WHERE id=?',(*values.values(),store.now(),run_id))


def inventory_page(run_id,ids,cursor):
    with store.connect() as db:
        db.executemany('INSERT OR IGNORE INTO bulk_items(run_id,remote_id) VALUES (?,?)',((run_id,i) for i in ids))
        db.execute('UPDATE bulk_runs SET cursor=?,phase=?,updated=? WHERE id=?',
                   (json.dumps(cursor) if cursor is not None else None,'inventory' if cursor is not None else 'sort',store.now(),run_id))


def retry_errors(run_id):
    with store.connect() as db:
        db.execute("UPDATE bulk_items SET status='pending',error='' WHERE run_id=? AND status='error'",(run_id,))


def next_item(run_id):
    with store.connect() as db:
        row=db.execute("SELECT * FROM bulk_items WHERE run_id=? AND status='pending' ORDER BY rowid LIMIT 1",(run_id,)).fetchone()
    return dict(row) if row else None


def finish_item(run_id,remote_id,status,row_id=None,error='',revision=''):
    if status not in {'done','review','error','missing'}:raise ValueError('Invalid item status')
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if revision:
            import label_settings
            current=db.execute("SELECT value FROM settings WHERE key='labels'").fetchone()
            if label_settings.revision(json.loads(current[0]) if current else label_settings.defaults())!=revision:
                status='pending'
        db.execute('UPDATE bulk_items SET status=?,row_id=?,error=? WHERE run_id=? AND remote_id=?',
                   (status,row_id,error,run_id,remote_id))


def runs():
    with store.connect() as db:
        rows=[dict(r) for r in db.execute('SELECT * FROM bulk_runs ORDER BY id DESC LIMIT 30')]
        # One grouped query replaces up to 30 separate count queries per poll.
        ids = [row['id'] for row in rows]
        totals = {}
        if ids:
            placeholders = ','.join('?' for _ in ids)
            for run_id, status, count in db.execute(
                f'SELECT run_id,status,COUNT(*) FROM bulk_items WHERE run_id IN ({placeholders}) GROUP BY run_id,status', ids):
                totals.setdefault(run_id, {})[status] = count
        for row in rows:
            row['counts'] = totals.get(row['id'], {})
            row['total'] = sum(row['counts'].values())
            row.pop('cursor')
    return rows


def counts(run_id):
    with store.connect() as db:
        return dict(db.execute('SELECT status,COUNT(*) FROM bulk_items WHERE run_id=? GROUP BY status',(run_id,)).fetchall())


def finish_if_idle(run_id):
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        statuses=dict(db.execute('SELECT status,COUNT(*) FROM bulk_items WHERE run_id=? GROUP BY status',(run_id,)).fetchall())
        if statuses.get('pending',0):return False
        failed=bool(statuses.get('error',0))
        db.execute('UPDATE bulk_runs SET status=?,error=?,updated=? WHERE id=?',
                   ('paused' if failed else 'complete','Some messages failed; resume to retry' if failed else '',store.now(),run_id))
    return True
