"""Private dashboard state, predictions, reviewed corrections, and write audit."""
import hashlib
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager

from runtime_paths import data_path

DATABASE = data_path('dashboard.sqlite3')
_schema_lock = threading.Lock()
_initialized = set()


def now():
    return datetime.now(timezone.utc).isoformat()


def _initialize(db):
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY, provider TEXT NOT NULL, account TEXT NOT NULL,
            remote_id TEXT NOT NULL, sender TEXT NOT NULL, subject TEXT NOT NULL,
            body TEXT NOT NULL, received TEXT NOT NULL, result TEXT NOT NULL,
            model TEXT NOT NULL, policy TEXT NOT NULL, reviewed INTEGER DEFAULT 0,
            applied INTEGER DEFAULT 0, review_source TEXT DEFAULT '', created TEXT NOT NULL,
            UNIQUE(provider,account,remote_id));
        CREATE TABLE IF NOT EXISTS corrections (
            id INTEGER PRIMARY KEY, message_id INTEGER NOT NULL, evidence TEXT NOT NULL,
            result TEXT NOT NULL, previous_result TEXT NOT NULL, reviewer TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS label_events (
            id INTEGER PRIMARY KEY, message_id INTEGER NOT NULL,
            labels TEXT NOT NULL, success INTEGER NOT NULL, error TEXT NOT NULL,
            created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS prediction_cache (key TEXT PRIMARY KEY, result TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bulk_runs (
            id INTEGER PRIMARY KEY, provider TEXT NOT NULL, account TEXT NOT NULL,
            status TEXT NOT NULL, phase TEXT NOT NULL, cursor TEXT,
            mode TEXT NOT NULL DEFAULT 'inbox', apply_labels INTEGER NOT NULL DEFAULT 1,
            error TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bulk_items (
            run_id INTEGER NOT NULL, remote_id TEXT NOT NULL, row_id INTEGER,
            status TEXT NOT NULL DEFAULT 'pending', error TEXT NOT NULL DEFAULT '',
            PRIMARY KEY(run_id,remote_id));
        CREATE INDEX IF NOT EXISTS bulk_pending ON bulk_items(run_id,status);
        CREATE INDEX IF NOT EXISTS messages_account ON messages(provider,account);
        CREATE INDEX IF NOT EXISTS correction_evidence ON corrections(evidence,id);
        CREATE INDEX IF NOT EXISTS label_history ON label_events(message_id,id DESC);
    ''')


@contextmanager
def connect():
    # DDL and journal setup run once per database inode, rather than on every
    # dashboard poll and message checkpoint. Connections remain thread-local.
    path = Path(DATABASE)
    db = None
    try:
        with _schema_lock:
            fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
            os.close(fd)
            identity = (str(path.resolve()), path.stat().st_ino)
            db = sqlite3.connect(path, timeout=15)
            db.row_factory = sqlite3.Row
            if identity not in _initialized:
                os.chmod(path, 0o600)
                _initialize(db)
                db.commit()
                _initialized.add(identity)
        yield db
        db.commit()
    except Exception:
        if db is not None:
            db.rollback()
        raise
    finally:
        if db is not None:
            db.close()


def evidence(message):
    return hashlib.sha256(json.dumps([message[k] for k in ('provider','account','sender','subject','body')],
                                   ensure_ascii=False).encode()).hexdigest()


def known(provider, account):
    with connect() as db:
        return {r[0] for r in db.execute('SELECT remote_id FROM messages WHERE provider=? AND account=?', (provider, account))}


def save(message, result, model, policy):
    with connect() as db:
        db.execute('''INSERT OR IGNORE INTO messages
            (provider,account,remote_id,sender,subject,body,received,result,model,policy,created)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
            (*(message[k] for k in ('provider','account','remote_id','sender','subject','body','received')),
             result.model_dump_json(), model, policy, now()))
        return db.execute('SELECT id FROM messages WHERE provider=? AND account=? AND remote_id=?',
                          tuple(message[k] for k in ('provider','account','remote_id'))).fetchone()[0]


def get(message_id):
    with connect() as db:
        row = db.execute('SELECT * FROM messages WHERE id=?', (message_id,)).fetchone()
    if row is None:
        raise ValueError('Message not found')
    return dict(row)


def find(provider,account,remote_id):
    with connect() as db:
        row=db.execute('SELECT * FROM messages WHERE provider=? AND account=? AND remote_id=?',
                       (provider,account,remote_id)).fetchone()
    return dict(row) if row else None


def last_labels(message_id):
    with connect() as db:
        row=db.execute('SELECT labels FROM label_events WHERE message_id=? AND success=1 ORDER BY id DESC LIMIT 1',(message_id,)).fetchone()
    return json.loads(row[0]) if row else []


def mark_current(message_id):
    with connect() as db:db.execute('UPDATE messages SET applied=1 WHERE id=?',(message_id,))


def cached_prediction(key,result=None):
    with connect() as db:
        if result is not None:
            db.execute('INSERT OR REPLACE INTO prediction_cache VALUES (?,?)',(key,result))
            return None
        row=db.execute('SELECT result FROM prediction_cache WHERE key=?',(key,)).fetchone()
    return row[0] if row else None


def list_messages(search='', provider='', category='', view='all', offset=0, limit=100):
    if provider not in {'','gmail','proton'} or view not in {'all','review','pending','applied'}:
        raise ValueError('Invalid message filter')
    if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 500:
        raise ValueError('Invalid page')
    clauses=[];args=[]
    if provider: clauses.append('provider=?');args.append(provider)
    if category: clauses.append("json_extract(result,'$.category')=?");args.append(category)
    if search:
        import label_settings
        config=label_settings.load()
        alternatives=["instr(lower(subject),lower(?))>0","instr(lower(sender),lower(?))>0",
                      "instr(lower(json_extract(result,'$.category')),lower(?))>0"]
        args.extend([search,search,search])
        for source in ('gmail','proton'):
            for cat,name in config[source].items():
                if search.casefold() in name.casefold():
                    alternatives.append("(provider=? AND json_extract(result,'$.category')=?)")
                    args.extend([source,cat])
        clauses.append('('+' OR '.join(alternatives)+')')
    if view=='review': clauses.append("reviewed=0 AND json_extract(result,'$.needs_review')=1")
    if view=='pending': clauses.append('applied=0')
    if view=='applied': clauses.append('applied=1')
    where=' WHERE '+' AND '.join(clauses) if clauses else ''
    with connect() as db:
        columns='id,provider,account,remote_id,sender,subject,received,result,model,policy,reviewed,applied,review_source,created'
        rows = [dict(r) for r in db.execute('SELECT '+columns+' FROM messages'+where+' ORDER BY id DESC LIMIT ? OFFSET ?', (*args,limit,offset))]
        filtered=db.execute('SELECT COUNT(*) FROM messages'+where,args).fetchone()[0]
        counts = db.execute('SELECT COUNT(*), COALESCE(SUM(applied),0), COALESCE(SUM(reviewed),0), '
                            "COALESCE(SUM(reviewed=0 AND json_extract(result,'$.needs_review')=1),0) FROM messages").fetchone()
    for row in rows:
        row['result'] = json.loads(row['result'])
    return rows, {'total':counts[0], 'applied':counts[1], 'reviewed':counts[2],
                  'needs_review':counts[3], 'filtered':filtered, 'offset':offset, 'limit':limit}


def correct(message_id, result, reviewer='dashboard'):
    row = get(message_id)
    with connect() as db:
        db.execute('INSERT INTO corrections (message_id,evidence,result,previous_result,reviewer,created) VALUES (?,?,?,?,?,?)',
                   (message_id, evidence(row), result.model_dump_json(), row['result'], reviewer, now()))
        db.execute('UPDATE messages SET result=?, reviewed=1, review_source=?, applied=0 WHERE id=?',
                   (result.model_dump_json(), reviewer, message_id))


def reviewed_result(message):
    with connect() as db:
        row = db.execute('SELECT result FROM corrections WHERE evidence=? ORDER BY id DESC LIMIT 1', (evidence(message),)).fetchone()
    return json.loads(row[0]) if row else None


def log_apply(message_id, labels, error=''):
    with connect() as db:
        db.execute('INSERT INTO label_events (message_id,labels,success,error,created) VALUES (?,?,?,?,?)',
                   (message_id, json.dumps(labels), int(not error), error, now()))
        if not error:
            db.execute('UPDATE messages SET applied=1 WHERE id=?', (message_id,))


def export_corrections():
    with connect() as db:
        rows = [dict(r) for r in db.execute('SELECT * FROM messages WHERE reviewed=1 ORDER BY id')]
    output = []
    for row in rows:
        r = json.loads(row['result'])
        output.append({'id': f"reviewed-{row['id']}", **{k:row[k] for k in ('sender','subject','body')},
                       **{k:r[k] for k in ('category','message_type','priority')}, 'review_source':row['review_source']})
    return output


def history(message_id):
    # Return the most recent audit entries for a single message, not its body.
    get(message_id)
    with connect() as db:
        labels = [dict(row) for row in db.execute(
            'SELECT labels,success,error,created FROM label_events WHERE message_id=? ORDER BY id DESC LIMIT 20',
            (message_id,))]
        reviews = [dict(row) for row in db.execute(
            'SELECT result,reviewer,created FROM corrections WHERE message_id=? ORDER BY id DESC LIMIT 20',
            (message_id,))]
    for row in labels:
        row['labels'] = json.loads(row['labels'])
    for row in reviews:
        row['result'] = json.loads(row['result'])
    return {'labels': labels, 'reviews': reviews}
