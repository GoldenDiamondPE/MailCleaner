"""Editable destinations; classifier categories stay stable across label changes."""
import copy
import hashlib
import json
import unicodedata
from typing import get_args
from classifier import Category
import mail_store as store

SYSTEM = {'INBOX','SENT','DRAFT','DRAFTS','SPAM','TRASH','UNREAD','IMPORTANT','STARRED',
          'CHAT','ALL','ALL MAIL','YELLOW_STAR','CATEGORY_PERSONAL','CATEGORY_SOCIAL','CATEGORY_PROMOTIONS',
          'CATEGORY_UPDATES','CATEGORY_FORUMS'}


def validate_name(name, provider, allow_empty=False):
    if not isinstance(name,str) or len(name)>100 or (not name and not allow_empty):
        raise ValueError('Label names must contain 1–100 characters')
    if name != name.strip() or any(unicodedata.category(ch).startswith('C') for ch in name):
        raise ValueError('Labels cannot contain control characters or surrounding whitespace')
    if provider=='proton' and '/' in name:
        raise ValueError('Proton label names cannot contain /; destinations are always Labels, not Folders')
    if any(not part.strip() for part in name.split('/')) and name:
        raise ValueError('Label paths cannot contain empty components')
    if name.split('/')[0].upper() in SYSTEM:
        raise ValueError('System folders/flags cannot be label destinations')
    return name


def defaults():
    return {'gmail_root':'MailCleaner','gmail':{c:'MailCleaner/'+c for c in get_args(Category)},
            'proton':{c:'MailCleaner - '+c.replace('/','-') for c in get_args(Category)}}


def load():
    with store.connect() as db:
        row=db.execute("SELECT value FROM settings WHERE key='labels'").fetchone()
    return json.loads(row[0]) if row else defaults()


def save(config,expected_revision=None):
    if not isinstance(config,dict) or set(config)!={'gmail_root','gmail','proton'}:
        raise ValueError('Expected Gmail root plus complete Gmail and Proton category mappings')
    validate_name(config['gmail_root'],'gmail',allow_empty=True)
    for provider in ('gmail','proton'):
        if not isinstance(config[provider],dict) or set(config[provider])!=set(get_args(Category)):
            raise ValueError('Every classifier category needs a label destination')
        for name in config[provider].values():validate_name(name,provider)
    config=copy.deepcopy(config)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute("SELECT value FROM settings WHERE key='labels'").fetchone()
        old=json.loads(row[0]) if row else defaults()
        if expected_revision is not None and revision(old)!=expected_revision:
            raise ValueError('Label settings changed in another window; reload saved settings before saving')
        changed=[p for p in ('gmail','proton') if config[p]!=old[p] or p=='gmail' and config['gmail_root']!=old['gmail_root']]
        db.execute("INSERT OR REPLACE INTO settings VALUES ('labels',?)",(json.dumps(config),))
        for provider in changed:
            categories=[cat for cat in config[provider] if config[provider][cat]!=old[provider][cat]]
            root_changed=provider=='gmail' and config['gmail_root']!=old['gmail_root']
            criterion='1' if root_changed else "json_extract(result,'$.category') IN ("+','.join('?' for _ in categories)+')'
            parameters=[] if root_changed else categories
            if 'Other / Review' in categories:criterion="("+criterion+" OR json_extract(result,'$.needs_review')=1)"
            db.execute('UPDATE messages SET applied=0 WHERE provider=? AND '+criterion,(provider,*parameters))
            db.execute("UPDATE bulk_items SET status='pending' WHERE status IN ('done','review') AND run_id IN "
                       "(SELECT id FROM bulk_runs WHERE provider=? AND status IN ('running','paused','queued')) "
                       "AND row_id IN (SELECT id FROM messages WHERE provider=? AND "+criterion+")",(provider,provider,*parameters))
            db.execute("INSERT OR IGNORE INTO bulk_items(run_id,remote_id) SELECT r.id,m.remote_id FROM bulk_runs r "
                       "JOIN messages m ON m.provider=r.provider AND m.account=r.account WHERE r.mode='saved' "
                       "AND r.provider=? AND r.status IN ('running','paused','queued') AND m.applied=0",(provider,))
    return config


def resolve(provider,categories,config=None):
    categories=list(dict.fromkeys(categories))
    if provider not in {'gmail','proton'} or not categories or any(c not in get_args(Category) for c in categories):
        raise ValueError('Invalid provider/category')
    config=load() if config is None else config
    names=[config[provider][c] for c in categories]
    if provider=='gmail' and config['gmail_root']:names.insert(0,config['gmail_root'])
    for name in names:validate_name(name,provider)
    return list(dict.fromkeys(names))


def fingerprint(provider,categories):
    return hashlib.sha256(json.dumps(resolve(provider,categories),ensure_ascii=False).encode()).hexdigest()


def revision(config=None):
    return hashlib.sha256(json.dumps(load() if config is None else config,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
