
import os
import hashlib
import sqlite3
import time
from datetime import datetime, timezone
from typing import get_args
from local_backend import PROVIDER, LMSTUDIO_URL
from mail_actions import gmail_add_labels, category_names
import label_settings

from gmail_client import get_gmail_service, extract_body
from classifier import Category, MODEL, PROMPT_VERSION, classify_email, EmailClassification, client, clean_email_text

from runtime_paths import data_path
DATABASE = str(data_path("mailcleaner.db"))
PREFIX = "MailCleaner/"
DRY_RUN = os.getenv("MAILCLEANER_APPLY", "0") != "1"
MAX_MESSAGES = int(os.getenv("MAILCLEANER_MAX_MESSAGES", "25")) or None
DELAY_SECONDS = float(os.getenv("MAILCLEANER_DELAY_SECONDS", "0"))
if (MAX_MESSAGES is not None and MAX_MESSAGES < 1) or DELAY_SECONDS < 0:
    raise ValueError("Message limit and delay must be nonnegative")

# Exclude spam, trash, sent messages and drafts.
QUERY = os.getenv("MAILCLEANER_QUERY", "in:inbox -in:spam -in:trash -in:sent -in:drafts")
INFERENCE_ID = f"{PROVIDER}/{MODEL}"


def setup_database():
    db = sqlite3.connect(DATABASE)
    db.execute("""
        CREATE TABLE IF NOT EXISTS processed (
            message_id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            processed_at TEXT NOT NULL
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS classification_log (
            message_id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            message_type TEXT NOT NULL,
            priority TEXT NOT NULL,
            summary TEXT NOT NULL,
            confidence REAL NOT NULL,
            needs_review INTEGER NOT NULL,
            model TEXT NOT NULL,
            prompt_version TEXT NOT NULL,
            applied INTEGER NOT NULL DEFAULT 0,
            classified_at TEXT NOT NULL
        )
    """)
    log_columns = {
        row[1] for row in db.execute("PRAGMA table_info(classification_log)")
    }
    if "applied" not in log_columns:
        db.execute(
            "ALTER TABLE classification_log "
            "ADD COLUMN applied INTEGER NOT NULL DEFAULT 0"
        )
    db.commit()
    db.execute("""CREATE TABLE IF NOT EXISTS inference_cache (
        fingerprint TEXT PRIMARY KEY, result TEXT NOT NULL
    )""")
    db.commit()
    return db


def cached_classification(db, email):
    # Exact content only. Never reuse a sender's label for a different email.
    evidence = (PROVIDER, LMSTUDIO_URL if PROVIDER == "lmstudio" else os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434"), MODEL, PROMPT_VERSION, os.getenv("MAILCLEANER_MIN_CONFIDENCE", "0.55"),
                email["sender"], email["subject"], clean_email_text(email["body"]))
    fingerprint = hashlib.sha256(repr(evidence).encode()).hexdigest()
    row = db.execute("SELECT result FROM inference_cache WHERE fingerprint = ?", (fingerprint,)).fetchone()
    if row:
        return EmailClassification.model_validate_json(row[0])
    result = classify_email(email["sender"], email["subject"], email["body"])
    db.execute("INSERT OR REPLACE INTO inference_cache VALUES (?, ?)",
               (fingerprint, result.model_dump_json()))
    db.commit()
    return result


def record_classification(db, message_id, result, applied):
    """Keep a local, body-free audit record for finding and correcting mistakes."""
    db.execute(
        """
        INSERT OR REPLACE INTO classification_log
        (message_id, category, message_type, priority, summary, confidence,
         needs_review, model, prompt_version, classified_at, applied)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            message_id, result.category, result.message_type, result.priority,
            result.summary, result.confidence, int(result.needs_review), INFERENCE_ID,
            PROMPT_VERSION, datetime.now(timezone.utc).isoformat(), int(applied),
        ),
    )
    db.commit()  # Persist dry-run audits too; previously close() rolled them back.


def get_labels(service):
    response = service.users().labels().list(
        userId="me"
    ).execute()

    return {
        label["name"]: label["id"]
        for label in response.get("labels", [])
    }


def ensure_label(service, labels, name):
    if name in labels:
        return labels[name]

    if DRY_RUN:
        return None

    result = service.users().labels().create(
        userId="me",
        body={
            "name": name,
            "labelListVisibility": "labelShow",
            "messageListVisibility": "show"
        }
    ).execute()

    labels[name] = result["id"]
    return result["id"]


def get_all_message_ids(service, limit=None):
    ids = []
    page_token = None

    while True:
        args = {
            "userId": "me",
            "q": QUERY,
            "maxResults": min(500, limit - len(ids)) if limit else 500
        }

        if page_token:
            args["pageToken"] = page_token

        response = service.users().messages().list(
            **args
        ).execute()

        ids.extend(
            message["id"]
            for message in response.get("messages", [])
        )

        if limit and len(ids) >= limit:
            return list(dict.fromkeys(ids))[:limit]

        page_token = response.get("nextPageToken")

        if not page_token:
            break

    return list(dict.fromkeys(ids))


def get_message(service, message_id):
    message = service.users().messages().get(
        userId="me",
        id=message_id,
        format="full"
    ).execute()

    headers = {
        h["name"].lower(): h["value"]
        for h in message["payload"].get("headers", [])
    }

    body = extract_body(message["payload"])

    if not body:
        body = message.get("snippet", "")

    return message, {
        "sender": headers.get("from", ""),
        "subject": headers.get("subject", ""),
        "body": body
    }


def apply_categories(service, labels, message, categories):
    """Apply the primary category and, when needed, a separate review label."""
    target_names = label_settings.resolve('gmail',categories)

    if DRY_RUN:
        for target_name in target_names:
            print(f"  WOULD LABEL: {target_name}")
        return

    gmail_add_labels(service, message['id'], categories, labels)


def main():
    if not DRY_RUN and (MAX_MESSAGES is None or MAX_MESSAGES > 100):
        raise ValueError('Label-only live runs require MAILCLEANER_MAX_MESSAGES between 1 and 100')
    started = time.perf_counter()
    client.show(MODEL)  # Fail once, before OAuth or scanning thousands of messages.
    print(f"Model: {MODEL} | policy: {PROMPT_VERSION} | dry run: {DRY_RUN}")
    service = get_gmail_service()
    db = setup_database()
    labels = get_labels(service)

    print("Retrieving all eligible Gmail messages...")
    message_ids = get_all_message_ids(service, MAX_MESSAGES)
    print(f"Found {len(message_ids)} messages.")

    processed = 0
    skipped = 0
    failed = 0

    for index, message_id in enumerate(message_ids, 1):
        # Only skip completed messages in live mode.
        if not DRY_RUN:
            existing = db.execute(
                "SELECT 1 FROM processed WHERE message_id = ? "
                "AND EXISTS (SELECT 1 FROM classification_log WHERE message_id = processed.message_id "
                "AND model = ? AND prompt_version = ? AND applied = 1)",
                (message_id, INFERENCE_ID, PROMPT_VERSION)
            ).fetchone()

            if existing:
                skipped += 1
                continue

        try:
            message, email = get_message(
                service, message_id
            )

            result = cached_classification(db, email)

            categories = [result.category]
            if result.needs_review and result.category != "Other / Review":
                categories.append("Other / Review")

            print(
                f"[{index}/{len(message_ids)}] "
                f"{email['subject'][:65]}"
            )
            print(
                f"  {result.category} | "
                f"{result.priority} | "
                f"{result.decision_source} | review={result.needs_review}"
            )
            print(f"  {result.summary}")

            apply_categories(
                service, labels, message, categories
            )

            record_classification(db, message_id, result, applied=not DRY_RUN)
            if not DRY_RUN:
                db.execute(
                    """
                    INSERT OR REPLACE INTO processed
                    (message_id, category, processed_at)
                    VALUES (?, ?, ?)
                    """,
                    (
                        message_id,
                        result.category,
                        datetime.now(timezone.utc).isoformat()
                    )
                )
                db.commit()

            processed += 1
            if DELAY_SECONDS:
                time.sleep(DELAY_SECONDS)

        except Exception as error:
            failed += 1
            print(f"  ERROR: {error}")
            if failed >= 3 and processed == 0:
                print("Stopping after three initial failures; check Ollama/model configuration.")
                break

    db.close()

    print("\nFinished.")
    print(f"Classified: {processed}")
    print(f"Previously processed: {skipped}")
    print(f"Failed: {failed}")
    print(f"Dry run: {DRY_RUN}")
    print(f"Elapsed: {time.perf_counter() - started:.1f}s")


if __name__ == "__main__":
    main()
