"""Resumable whole-inbox worker. Inventory first, then checkpoint every message."""
import json
import classifier as c
import mail_store as store
import bulk_store as bulk
import label_settings
from predictor import predict
from mailboxes import MessageGone


def categories_for(row, automatic=False):
    result=c.EmailClassification.model_validate_json(row['result'])
    needs_review=(result.needs_review and not row['reviewed']) or result.category=='Account Security'
    if automatic and needs_review and result.category!='Account Security':
        return ['Other / Review']
    categories=[result.category]
    if needs_review and result.category!='Other / Review':categories.append('Other / Review')
    return categories


def desired_labels(provider,categories):
    names=label_settings.resolve(provider,categories)
    return ['Labels/'+name for name in names] if provider=='proton' else names


def apply_one(row,mailbox,automatic=False):
    categories=categories_for(row,automatic)
    desired=desired_labels(row['provider'],categories)
    # Audit history is not proof that a label still exists remotely. A new run
    # re-adds current destinations idempotently; resume skips checkpointed items.
    try:
        labels=mailbox.apply(row,categories)
        store.log_apply(row['id'],labels)
        return labels
    except Exception as error:
        # Store no untrusted credential-bearing exception text here.
        store.log_apply(row['id'],desired,type(error).__name__+': label action failed')
        raise


class Runner:
    def __init__(self,service):self.service=service

    def start(self,providers,mode='inbox',apply_labels=True):
        if not isinstance(providers,list) or not providers or len(providers)>2 or any(p not in {'gmail','proton'} for p in providers):
            raise ValueError('Choose Gmail, Proton or both')
        if mode not in {'inbox','saved'} or type(apply_labels) is not bool:raise ValueError('Invalid whole-inbox options')
        providers=list(dict.fromkeys(providers))
        if 'proton' in providers and not self.service.bridge:raise ValueError('Connect Proton Bridge first')
        def work():
            run_ids=[]
            try:
                for provider in providers:
                    mailbox=self.service.mailbox(provider)
                    try:run_ids.append(bulk.create(provider,mailbox.account,mode,apply_labels))
                    finally:mailbox.close()
                if mode!='saved':c.client.show(c.MODEL)
                for run_id in run_ids:
                    if self.service.cancelled.is_set():break
                    run=bulk.get(run_id);mailbox=self.service.mailbox(run['provider'])
                    try:
                        if mailbox.account.casefold()!=run['account'].casefold():raise ValueError('Mailbox account changed during startup')
                        self.execute(run_id,mailbox)
                    finally:mailbox.close()
                    if bulk.get(run_id)['status']!='complete':break
            except Exception as error:
                for run_id in run_ids:
                    if bulk.get(run_id)['status']!='complete':bulk.update(run_id,status='paused',error=self.service.error(error))
                raise
            finally:
                for run_id in run_ids:
                    if bulk.get(run_id)['status'] in {'running','queued'}:bulk.update(run_id,status='paused')
        self.service.start('Sort entire inbox' if apply_labels else 'Preview entire inbox',work)

    def resume(self,run_id):
        run=bulk.get(run_id)
        if run['status'] in {'complete','cancelled'}:raise ValueError('This run has ended; start another run for new mail or label changes')
        if run['provider']=='proton' and not self.service.bridge:raise ValueError('Reconnect Proton Bridge before resuming')
        def work():
            mailbox=self.service.mailbox(run['provider'])
            try:
                if mailbox.account.casefold()!=run['account'].casefold():raise ValueError('Run belongs to a different mailbox account')
                if run['mode']!='saved':c.client.show(c.MODEL)
                bulk.retry_errors(run_id);self.execute(run_id,mailbox)
            except Exception as error:
                bulk.update(run_id,status='paused',error=self.service.error(error));raise
            finally:mailbox.close()
        self.service.start(f'Resume inbox run {run_id}',work)

    def execute(self,run_id,mailbox):
        service=self.service
        bulk.update(run_id,status='running',error='')
        with service.lock:service.job['bulk_id']=run_id
        try:
            run=bulk.get(run_id)
            if run['provider']=='proton':
                with store.connect() as db:
                    first=db.execute('SELECT remote_id FROM bulk_items WHERE run_id=? LIMIT 1',(run_id,)).fetchone()
                if first and first[0].split(':')[1]!=mailbox.validity:
                    raise ValueError('Proton Inbox identity changed; end this run and start a fresh inventory')
            while run['phase']=='inventory':
                if service.cancelled.is_set():bulk.update(run_id,status='paused');return
                cursor=json.loads(run['cursor']) if run['cursor'] else None
                if run['mode']=='saved':
                    after=(cursor or {}).get('after',0)
                    with store.connect() as db:
                        page=db.execute('SELECT id,remote_id FROM messages WHERE provider=? AND account=? AND applied=0 AND id>? ORDER BY id LIMIT 500',
                                        (run['provider'],run['account'],after)).fetchall()
                    ids=[r['remote_id'] for r in page];next_cursor={'after':page[-1]['id']} if len(page)==500 else None
                else:
                    try:ids,next_cursor=mailbox.inventory_page(cursor)
                    except Exception as error:
                        if run['provider']=='gmail' and cursor and getattr(getattr(error,'resp',None),'status',None)==400:
                            with store.connect() as db:db.execute('UPDATE bulk_runs SET cursor=NULL WHERE id=?',(run_id,))
                            run=bulk.get(run_id);continue
                        raise
                bulk.inventory_page(run_id,ids,next_cursor)
                run=bulk.get(run_id)
            failures=0
            while True:
                if service.cancelled.is_set():bulk.update(run_id,status='paused');return
                item=bulk.next_item(run_id)
                if item is None:
                    if bulk.finish_if_idle(run_id):return
                    continue
                row=None
                try:
                    row=store.find(run['provider'],run['account'],item['remote_id'])
                    if row is None:
                        message=mailbox.read(item['remote_id'])
                        result=predict(message)
                        row_id=store.save(message,result,c.model_identity(),c.PROMPT_VERSION);row=store.get(row_id)
                    elif run['mode']!='saved' and not row['reviewed'] and row['policy']!=c.PROMPT_VERSION and row['body']:
                        result=predict(row)
                        candidate={**row,'result':result.model_dump_json()}
                        still_applied=int(set(desired_labels(row['provider'],categories_for(candidate)))<=set(store.last_labels(row['id'])))
                        with store.connect() as db:
                            db.execute('UPDATE messages SET result=?,model=?,policy=?,applied=? WHERE id=? AND reviewed=0',
                                       (result.model_dump_json(),c.model_identity(),c.PROMPT_VERSION,still_applied,row['id']))
                        row=store.get(row['id'])
                    revision=label_settings.revision()
                    categories=categories_for(row,automatic=True)
                    if run['apply_labels']:apply_one(row,mailbox,automatic=True)
                    flagged=categories==['Other / Review'] or 'Account Security' in categories
                    bulk.finish_item(run_id,item['remote_id'],'review' if flagged else 'done',row['id'],revision=revision)
                    failures=0
                    with service.lock:
                        service.job['completed']+=1
                        service.job['ids']=(service.job['ids']+[row['id']])[-20:]
                except MessageGone:
                    bulk.finish_item(run_id,item['remote_id'],'missing',row['id'] if row else None)
                except Exception as error:
                    failures+=1;text=service.error(error)
                    bulk.finish_item(run_id,item['remote_id'],'error',row['id'] if row else None,text)
                    with service.lock:service.job['errors']=(service.job['errors']+[text])[-10:]
                    if failures>=3:
                        bulk.update(run_id,status='paused',error='Stopped after three consecutive errors; resume to retry');return
        except Exception as error:
            bulk.update(run_id,status='paused',error=service.error(error))
            raise
