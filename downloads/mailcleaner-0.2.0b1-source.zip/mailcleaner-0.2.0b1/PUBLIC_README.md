# MailCleaner · public beta

A local workspace for sorting Gmail and Proton Mail with AI. Preview messages,
review classifications, customize destinations, and run a resumable whole-inbox
sort. MailCleaner only adds labels. It never deletes, archives, marks messages
read, removes existing labels, or moves messages out of the inbox.

**Release candidate 0.2.0b1.** This update has not yet completed release testing.
The downloadable build is a Python application, not a signed or notarized Mac
installer. No hosted mailbox service or public dashboard server is included.

## Install on a Mac

You need Python 3.11 or newer, Ollama with `qwen3:1.7b`, and a modern browser.
The model and runtime are separate downloads with their own licenses.

Download and extract the source archive, then open Terminal in that folder:

```sh
python3 -m venv .venv
./.venv/bin/python -m pip install .
ollama pull qwen3:1.7b
./.venv/bin/mailcleaner --open
```

Alternatively install the supplied wheel inside a virtual environment:

```sh
python3 -m venv .venv
./.venv/bin/python -m pip install ./mailcleaner_local-0.2.0b1-py3-none-any.whl
./.venv/bin/mailcleaner --open
```

Dependencies are fetched from the Python package index during installation.
MailCleaner opens at `http://127.0.0.1:8765`. Leave the Terminal process running
while sorting. Use Ctrl+C to stop after saving the current operation. If a
different copy is already running, open that dashboard or choose `--port 8766`.
Run only one instance against each data directory.

## Connect your mail

**Gmail:** this beta uses a Google OAuth Desktop client you create in your own
Google Cloud project. Enable Gmail API, configure OAuth consent, add your account
as a test user when appropriate, and download the Desktop client JSON. Import it
under Connections, then choose Connect Gmail. Your account password is entered
only on Google's authorization page. See [Google's setup guide](https://developers.google.com/workspace/gmail/api/quickstart/python).

The `gmail.modify` permission is broad enough to support reading and labeling.
MailCleaner's implementation only reads mail and adds labels. A branded public
OAuth app needs a verification review or an applicable exception before broad
distribution; see [Google's scope verification requirements](https://developers.google.com/identity/protocols/oauth2/production-readiness/restricted-scope-verification).

**Proton:** run Proton Mail Bridge with an eligible paid plan on the same
computer. Under Connections enter the Bridge-generated IMAP username/password
and port. Export TLS certificates from Bridge's advanced settings and paste only
the public certificate. Never paste the private key. Bridge credentials remain
in memory and must be entered again after a restart. MailCleaner is not an
officially supported Proton email client. See [Proton's Bridge documentation](https://proton.me/support/imap-smtp-and-pop3-setup).

## Use it carefully

1. Preview a small batch; this reads messages without applying labels.
2. Review categories and message purposes in Messages. Save corrections where
   needed. Small models can make mistakes, including on sensitive email.
3. Customize Gmail and Proton destinations in Labels. Categories are fixed;
   destination names are editable and multiple categories can share one label.
4. Choose Preview entire inbox or Sort entire inbox under Inbox runs. Runs save
   inventory and progress, and can be paused and resumed. Large inboxes take time.

Uncertain messages use the Review destination. Security messages also receive
their security label. Changing destination settings never removes old labels.
Choose Add updated labels to saved mail to apply changed names to saved results.
Human corrections are reused for exactly matching content and account evidence;
they do not train model weights. Scores are not calibrated accuracy guarantees.

## Private storage and configuration

Fresh Mac installations store application data in
`~/Library/Application Support/MailCleaner`. Linux uses the XDG user data
directory, and Windows uses Local AppData; those platforms need release
validation. Existing source installations keep their data in their original
directory. Set `MAILCLEANER_DATA_DIR` before launch to choose a separate directory.
Keep that directory private and protect backups. Files are not encrypted by
MailCleaner. See [PRIVACY.md](docs/PRIVACY.md).

Ollama is the default backend. Start another supported local backend with:

```sh
MAILCLEANER_PROVIDER=lmstudio MAILCLEANER_MODEL=your-local-model-id ./.venv/bin/mailcleaner --open
```

LM Studio defaults to `http://127.0.0.1:1234/v1`; configure `LMSTUDIO_BASE_URL` if
needed. Ollama defaults to `http://127.0.0.1:11434`; configure `OLLAMA_HOST` if
needed. Both servers must be on loopback. Do not expose the dashboard or model
ports with a public tunnel, reverse proxy, or port forwarding.

## Build and release

The release script copies an explicit list of source files into a clean temporary
directory. It does not glob the project or bundle local databases, OAuth files,
certificates, inbox text, validation history, or private reports.

```sh
python3 -m venv .build-venv
./.build-venv/bin/python -m pip install build setuptools wheel
./.build-venv/bin/python scripts/build_release.py
```

`dist/` contains a wheel, source ZIP, checksums, a manifest, and a separate static
public-site bundle. Only the static site is suitable for public web hosting. It
has a synthetic illustration and no connection to your mail data. Never host
the project directory or private dashboard.

Read [RELEASE.md](docs/RELEASE.md) for remaining release gates and
[ROADMAP.md](docs/ROADMAP.md) for prioritized follow-up work. No project license
has been selected; this build does not add an open-source license grant.
Third-party packages and models retain their respective licenses.

Independent project, not affiliated with Google, Proton, Ollama, or Qwen.
